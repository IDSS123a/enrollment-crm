// Google Sheets integration utilities

import type { Lead } from "./api"

const SPREADSHEET_ID = "1IMc5T_rB9w9j84P7kXS6bI_SHAFHQt5UF0M2wZz0C9o"
export const SHEET_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/edit`
const DEFAULT_WEB_APP_URL =
  "https://script.google.com/macros/s/AKfycbxlnHBjYpHwedxru2BgbOmb8BtEqKtuv2ZOVl20UuWBLK5BI9enEjO9yxEXs_zLG7qH/exec"

export async function initGoogleSheets(): Promise<boolean> {
  return new Promise((resolve) => {
    if (typeof window !== "undefined") {
      localStorage.setItem("spreadsheet_id", SPREADSHEET_ID)
      localStorage.setItem("sheets_connected", "true")
      console.log("Google Sheets initialized with ID:", SPREADSHEET_ID)
    }
    resolve(true)
  })
}

export async function syncToGoogleSheets(leadData: Partial<Lead>): Promise<{ success: boolean; message: string }> {
  try {
    const webAppUrl =
      (typeof window !== "undefined" && localStorage.getItem("sheets_web_app_url")) || DEFAULT_WEB_APP_URL
    const proxyUrl = `https://proxy-api.trickle-app.host/?url=${encodeURIComponent(webAppUrl)}`

    const payload = {
      action: "add",
      date: new Date().toLocaleDateString("en-US"),
      time: new Date().toLocaleTimeString("en-US"),
      name: leadData.name || "",
      email: leadData.email || "",
      phone: leadData.phone || "",
      status: leadData.status || "new",
      source: leadData.source || "Direct",
    }

    console.log("Syncing lead to Google Sheets:", payload)

    const response = await fetch(proxyUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    const result = await response.json()
    console.log("Sync response:", result)

    if (result.success) {
      console.log("✅ Lead synced to Google Sheets successfully")
      return { success: true, message: "Successfully synced to Google Sheets" }
    } else {
      console.error("❌ Sync failed:", result.error || "Unknown error")
      throw new Error(result.error || "Sync failed")
    }
  } catch (error) {
    console.error("Failed to sync to Google Sheets:", error)
    throw error
  }
}

export async function deleteFromGoogleSheets(leadEmail: string): Promise<{ success: boolean; message: string }> {
  try {
    const webAppUrl =
      (typeof window !== "undefined" && localStorage.getItem("sheets_web_app_url")) || DEFAULT_WEB_APP_URL
    const proxyUrl = `https://proxy-api.trickle-app.host/?url=${encodeURIComponent(webAppUrl)}`

    const payload = {
      action: "delete",
      email: leadEmail,
    }

    console.log("Deleting lead from Google Sheets:", leadEmail)

    const response = await fetch(proxyUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    const result = await response.json()
    console.log("Delete response:", result)

    if (result.success) {
      console.log("✅ Lead successfully deleted from Google Sheets:", leadEmail)
      return { success: true, message: "Successfully deleted from Google Sheets" }
    } else {
      console.error("❌ Failed to delete from Google Sheets:", result.message || "Unknown error")
      throw new Error(result.message || "Delete failed")
    }
  } catch (error) {
    console.error("Failed to delete from Google Sheets:", error)
    throw error
  }
}

export async function loadFromGoogleSheets(): Promise<Lead[]> {
  try {
    const webAppUrl =
      (typeof window !== "undefined" && localStorage.getItem("sheets_web_app_url")) || DEFAULT_WEB_APP_URL

    console.log("Loading leads from Google Sheets...")

    const proxyUrl = `https://proxy-api.trickle-app.host/?url=${encodeURIComponent(webAppUrl)}`

    const response = await fetch(proxyUrl, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    console.log("Raw Google Sheets data:", data)

    const parsedLeads = parseSheetData(data)
    console.log("Parsed leads from Google Sheets:", parsedLeads)

    return parsedLeads
  } catch (error) {
    console.error("Failed to load from Google Sheets:", error)
    return []
  }
}

function parseSheetData(data: any): Lead[] {
  if (!data || !data.values || data.values.length === 0) {
    console.log("No data in Google Sheets")
    return []
  }

  const rows = data.values.slice(1)

  if (rows.length === 0) {
    console.log("Only header row found in Google Sheets")
    return []
  }

  return rows
    .map((row: any[], index: number) => {
      if (!row || row.length < 4) {
        return null
      }

      return {
        id: "sheet_" + Date.now() + "_" + index,
        name: row[2] || "",
        email: row[3] || "",
        phone: row[4] || "",
        status: (row[5] || "new").toLowerCase() as Lead["status"],
        source: row[6] || "",
      }
    })
    .filter((lead): lead is Lead => lead !== null && !!lead.name && !!lead.email)
}
