"use client"

function CampaignCard({ campaign, onEdit, onDelete }) {
  try {
    const getStatusColor = (status) => {
      const colors = {
        active: "bg-green-100 text-green-700 border border-green-200",
        paused: "bg-amber-100 text-amber-700 border border-amber-200",
        completed: "bg-blue-100 text-blue-700 border border-blue-200",
      }
      return colors[status] || "bg-gray-100 text-gray-700 border border-gray-200"
    }

    const conversionRate = campaign.leads > 0 ? ((campaign.conversions / campaign.leads) * 100).toFixed(1) : 0

    const roi = campaign.spent > 0 ? (((campaign.revenue - campaign.spent) / campaign.spent) * 100).toFixed(0) : 0

    const budgetUsed = campaign.budget > 0 ? ((campaign.spent / campaign.budget) * 100).toFixed(0) : 0

    return (
      <div
        className="card hover:shadow-xl transition-all duration-300"
        data-name="campaign-card"
        data-file="components/CampaignCard.js"
      >
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1">
            <h3 className="text-xl font-bold text-[var(--text-primary)] mb-2">{campaign.name}</h3>
            <span className={`badge ${getStatusColor(campaign.status)} uppercase text-xs font-semibold`}>
              {campaign.status}
            </span>
          </div>
          <div className="flex gap-1">
            <button onClick={() => onEdit(campaign)} className="p-2.5 hover:bg-blue-50 rounded-lg transition-colors">
              <div className="icon-edit text-lg text-blue-600"></div>
            </button>
            <button
              onClick={() => onDelete(campaign.id)}
              className="p-2.5 hover:bg-red-50 rounded-lg transition-colors"
            >
              <div className="icon-trash-2 text-lg text-red-600"></div>
            </button>
          </div>
        </div>

        <p className="text-sm text-[var(--text-secondary)] mb-5 leading-relaxed">{campaign.description}</p>

        <div className="grid grid-cols-2 gap-4 mb-5">
          <div className="p-4 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-lg">
            <p className="text-xs text-[var(--text-secondary)] mb-1 uppercase tracking-wider font-semibold">Budget</p>
            <p className="text-xl font-bold text-[var(--primary-color)]">${campaign.budget?.toLocaleString()}</p>
            <div className="w-full bg-white rounded-full h-2 mt-3 shadow-inner">
              <div
                className="gradient-primary h-2 rounded-full transition-all duration-500"
                style={{ width: `${budgetUsed}%` }}
              ></div>
            </div>
            <p className="text-xs text-[var(--text-secondary)] mt-2">
              {budgetUsed}% used (${campaign.spent?.toLocaleString()})
            </p>
          </div>
          <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg">
            <p className="text-xs text-[var(--text-secondary)] mb-1 uppercase tracking-wider font-semibold">ROI</p>
            <p className="text-xl font-bold text-green-600">+{roi}%</p>
            <p className="text-xs text-[var(--text-secondary)] mt-3">Revenue</p>
            <p className="text-sm font-bold text-green-700">${campaign.revenue?.toLocaleString()}</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-5 p-4 bg-gradient-to-br from-gray-50 to-slate-50 rounded-lg">
          <div className="text-center">
            <p className="text-2xl font-bold text-[var(--text-primary)]">{campaign.leads}</p>
            <p className="text-xs text-[var(--text-secondary)] uppercase tracking-wider mt-1">Leads</p>
          </div>
          <div className="text-center border-x border-gray-200">
            <p className="text-2xl font-bold text-[var(--text-primary)]">{campaign.conversions}</p>
            <p className="text-xs text-[var(--text-secondary)] uppercase tracking-wider mt-1">Conversions</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-green-600">{conversionRate}%</p>
            <p className="text-xs text-[var(--text-secondary)] uppercase tracking-wider mt-1">Rate</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {campaign.channels?.map((channel, idx) => (
            <span
              key={idx}
              className="px-3 py-1.5 bg-gradient-to-r from-purple-50 to-pink-50 text-purple-700 text-xs font-semibold rounded-full border border-purple-100"
            >
              {channel}
            </span>
          ))}
        </div>
      </div>
    )
  } catch (error) {
    console.error("CampaignCard component error:", error)
    return null
  }
}
