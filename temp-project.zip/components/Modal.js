function Modal({ children, onClose, title }) {
  try {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50" onClick={onClose}>
        <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
          <div className="flex justify-between items-center p-6 border-b border-[var(--border-color)]">
            <h2 className="text-2xl font-bold text-[var(--text-primary)]">{title}</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
              <div className="icon-x text-xl text-[var(--text-secondary)]"></div>
            </button>
          </div>
          <div className="p-6">
            {children}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Modal component error:', error);
    return null;
  }
}
