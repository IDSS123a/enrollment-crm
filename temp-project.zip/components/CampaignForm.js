function CampaignForm({ campaign, onSave, onCancel }) {
  try {
    const [formData, setFormData] = React.useState({
      name: campaign?.name || '',
      description: campaign?.description || '',
      budget: campaign?.budget || '',
      status: campaign?.status || 'active',
      startDate: campaign?.startDate || '',
      endDate: campaign?.endDate || '',
      channels: campaign?.channels?.join(', ') || '',
    });

    const handleSubmit = (e) => {
      e.preventDefault();
      const channelsArray = formData.channels.split(',').map(c => c.trim()).filter(c => c);
      onSave({
        ...formData,
        budget: parseFloat(formData.budget),
        channels: channelsArray,
      });
    };

    const handleChange = (e) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Campaign Name</label>
          <input type="text" name="name" className="input" value={formData.name} onChange={handleChange} required />
        </div>
        <div>
          <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Description</label>
          <textarea name="description" className="input" rows="3" value={formData.description} onChange={handleChange} required></textarea>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Budget ($)</label>
            <input type="number" name="budget" className="input" value={formData.budget} onChange={handleChange} required />
          </div>
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Status</label>
            <select name="status" className="input" value={formData.status} onChange={handleChange}>
              <option value="active">Active</option>
              <option value="paused">Paused</option>
              <option value="completed">Completed</option>
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Start Date</label>
            <input type="date" name="startDate" className="input" value={formData.startDate} onChange={handleChange} required />
          </div>
          <div>
            <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">End Date</label>
            <input type="date" name="endDate" className="input" value={formData.endDate} onChange={handleChange} required />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Channels (comma separated)</label>
          <input type="text" name="channels" className="input" value={formData.channels} onChange={handleChange} placeholder="Social Media, Email, Website" />
        </div>
        <div className="flex gap-3 pt-4">
          <button type="submit" className="btn btn-primary flex-1">Save Campaign</button>
          <button type="button" onClick={onCancel} className="btn btn-secondary flex-1">Cancel</button>
        </div>
      </form>
    );
  } catch (error) {
    console.error('CampaignForm component error:', error);
    return null;
  }
}
