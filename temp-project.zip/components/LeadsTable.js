function LeadsTable({ leads, isLoading, onEdit, onDelete }) {
  try {
    const getStatusColor = (status) => {
      const colors = {
        new: 'bg-blue-100 text-blue-800',
        contacted: 'bg-yellow-100 text-yellow-800',
        qualified: 'bg-purple-100 text-purple-800',
        converted: 'bg-green-100 text-green-800',
        rejected: 'bg-red-100 text-red-800',
      };
      return colors[status] || 'bg-gray-100 text-gray-800';
    };

    if (isLoading) {
      return <div className="card text-center py-8">Loading leads...</div>;
    }

    return (
      <div className="card overflow-hidden" data-name="leads-table" data-file="components/LeadsTable.js">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-[var(--border-color)]">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase">Phone</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase">Source</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-[var(--text-secondary)] uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border-color)]">
              {leads.map((lead) => (
                <tr key={lead.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-[var(--text-primary)]">{lead.name}</td>
                  <td className="px-6 py-4 text-sm text-[var(--text-secondary)]">{lead.email}</td>
                  <td className="px-6 py-4 text-sm text-[var(--text-secondary)]">{lead.phone || '-'}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(lead.status)}`}>
                      {lead.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-[var(--text-secondary)]">{lead.source || '-'}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <button onClick={() => onEdit(lead)} className="p-2 hover:bg-gray-100 rounded-lg">
                        <div className="icon-edit text-lg text-blue-600"></div>
                      </button>
                      <button onClick={() => onDelete(lead.id)} className="p-2 hover:bg-gray-100 rounded-lg">
                        <div className="icon-trash-2 text-lg text-red-600"></div>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  } catch (error) {
    console.error('LeadsTable component error:', error);
    return null;
  }
}
