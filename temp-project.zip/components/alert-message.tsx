"use client"

import { CheckCircle, XCircle, AlertCircle, Info, X } from "lucide-react"
import { cn } from "@/lib/cn"

type AlertType = "success" | "error" | "warning" | "info"

interface AlertMessageProps {
  type: AlertType
  message: string
  onClose?: () => void
}

const alertConfig = {
  success: {
    icon: CheckCircle,
    bgColor: "bg-success/10",
    borderColor: "border-success",
    textColor: "text-success",
  },
  error: {
    icon: XCircle,
    bgColor: "bg-destructive/10",
    borderColor: "border-destructive",
    textColor: "text-destructive",
  },
  warning: {
    icon: AlertCircle,
    bgColor: "bg-warning/10",
    borderColor: "border-warning",
    textColor: "text-warning",
  },
  info: {
    icon: Info,
    bgColor: "bg-info/10",
    borderColor: "border-info",
    textColor: "text-info",
  },
}

export function AlertMessage({ type, message, onClose }: AlertMessageProps) {
  const config = alertConfig[type]
  const Icon = config.icon

  return (
    <div
      className={cn("flex items-center gap-3 rounded-lg border-l-4 p-4 shadow-md", config.bgColor, config.borderColor)}
    >
      <Icon className={cn("h-5 w-5 flex-shrink-0", config.textColor)} />
      <p className={cn("flex-1 text-sm font-medium", config.textColor)}>{message}</p>
      {onClose && (
        <button onClick={onClose} className={cn("hover:opacity-70 transition-opacity", config.textColor)}>
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  )
}
