function MetricCard({ title, value, change, trend, icon }) {
  try {
    const isPositive = trend === "up"

    const gradientClass = isPositive ? "gradient-success" : "gradient-danger"

    return (
      <div className="stat-card" data-name="metric-card" data-file="components/MetricCard.js">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <h3 className="text-sm font-medium text-[var(--text-secondary)] mb-2 uppercase tracking-wider">{title}</h3>
            <p className="text-3xl font-bold text-[var(--text-primary)] mb-1">{value}</p>
            {change && (
              <div
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                  isPositive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                }`}
              >
                <div className={`icon-${isPositive ? "trending-up" : "trending-down"} text-sm`}></div>
                {change}
              </div>
            )}
          </div>
          <div className={`w-14 h-14 ${gradientClass} rounded-xl flex items-center justify-center shadow-lg`}>
            <div className={`icon-${icon} text-2xl text-white`}></div>
          </div>
        </div>
      </div>
    )
  } catch (error) {
    console.error("MetricCard component error:", error)
    return null
  }
}
