function LeadsChart({ data }) {
  const chartRef = React.useRef(null);
  const chartInstance = React.useRef(null);

  React.useEffect(() => {
    if (!chartRef.current || !data || data.length === 0) return;

    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    chartInstance.current = new ChartJS(ctx, {
      type: 'line',
      data: {
        labels: data.map(d => d.name),
        datasets: [
          {
            label: 'Leads',
            data: data.map(d => d.leads),
            borderColor: 'rgb(37, 99, 235)',
            backgroundColor: 'rgba(37, 99, 235, 0.1)',
            tension: 0.4,
          },
          {
            label: 'Conversions',
            data: data.map(d => d.conversions),
            borderColor: 'rgb(16, 185, 129)',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            tension: 0.4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'top',
          },
        },
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data]);

  try {
    return (
      <div style={{ height: '300px' }} data-name="leads-chart" data-file="components/LeadsChart.js">
        <canvas ref={chartRef}></canvas>
      </div>
    );
  } catch (error) {
    console.error('LeadsChart component error:', error);
    return null;
  }
}
