import { cn } from "@/lib/cn"
import type { ReactNode } from "react"

interface MaterialCardProps {
  children: ReactNode
  className?: string
  gradient?: boolean
  hover?: boolean
}

export function MaterialCard({ children, className, gradient = false, hover = true }: MaterialCardProps) {
  return (
    <div
      className={cn(
        "rounded-lg bg-card p-6 transition-all duration-300",
        gradient ? "gradient-primary text-primary-foreground" : "material-shadow-md",
        hover && "hover:material-shadow-lg hover:-translate-y-0.5",
        className,
      )}
    >
      {children}
    </div>
  )
}

interface StatCardProps {
  title: string
  value: string | number
  icon: ReactNode
  trend?: {
    value: string
    positive: boolean
  }
  gradient?: boolean
}

export function StatCard({ title, value, icon, trend, gradient }: StatCardProps) {
  return (
    <MaterialCard gradient={gradient} className={gradient ? "" : "border border-border"}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className={cn("text-sm font-medium", gradient ? "text-primary-foreground/80" : "text-muted-foreground")}>
            {title}
          </p>
          <p className={cn("mt-2 text-3xl font-bold", gradient ? "text-primary-foreground" : "text-foreground")}>
            {value}
          </p>
          {trend && (
            <p
              className={cn(
                "mt-2 text-sm font-medium",
                gradient ? "text-primary-foreground/90" : trend.positive ? "text-success" : "text-destructive",
              )}
            >
              {trend.positive ? "↑" : "↓"} {trend.value}
            </p>
          )}
        </div>
        <div className={cn("rounded-lg p-3", gradient ? "bg-white/20" : "bg-primary/10")}>{icon}</div>
      </div>
    </MaterialCard>
  )
}
