function Alert({ type = 'info', message, onClose }) {
  try {
    const styles = {
      error: 'bg-red-50 border-red-200 text-red-800',
      success: 'bg-green-50 border-green-200 text-green-800',
      warning: 'bg-yellow-50 border-yellow-200 text-yellow-800',
      info: 'bg-blue-50 border-blue-200 text-blue-800',
    };

    const icons = {
      error: 'alert-circle',
      success: 'check-circle',
      warning: 'alert-triangle',
      info: 'info',
    };

    return (
      <div className={`p-4 rounded-lg border mb-4 flex items-center justify-between ${styles[type]}`} data-name="alert" data-file="components/Alert.js">
        <div className="flex items-center gap-3">
          <div className={`icon-${icons[type]} text-xl`}></div>
          <p className="text-sm font-medium">{message}</p>
        </div>
        {onClose && (
          <button onClick={onClose} className="hover:opacity-70">
            <div className="icon-x text-lg"></div>
          </button>
        )}
      </div>
    );
  } catch (error) {
    console.error('Alert component error:', error);
    return null;
  }
}
