"use client"

import { LayoutDashboard, Users, BarChart3, Megaphone, Settings, LogOut, CheckCircle } from "lucide-react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useAuth } from "@/app/providers"
import { cn } from "@/lib/cn"

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "Leads", href: "/leads", icon: Users },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
  { name: "Campaigns", href: "/campaigns", icon: Megaphone },
  { name: "Settings", href: "/settings", icon: Settings },
]

export function AppSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { logout } = useAuth()

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  return (
    <div className="flex h-screen w-64 flex-col bg-gradient-to-b from-[#5e35b1] to-[#4527a0] text-white">
      {/* Logo */}
      <div className="flex h-16 items-center gap-3 px-6 border-b border-white/10">
        <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
          <span className="text-2xl font-bold">I</span>
        </div>
        <div>
          <h1 className="text-lg font-bold">IDSS Pro</h1>
          <p className="text-xs text-white/70">Enrollment CRM</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 px-3 py-4">
        {navigation.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                isActive ? "bg-white/20 text-white shadow-lg" : "text-white/70 hover:bg-white/10 hover:text-white",
              )}
            >
              <item.icon className="h-5 w-5" />
              {item.name}
            </Link>
          )
        })}
      </nav>

      {/* Google Sheets Status */}
      <div className="px-6 py-4 border-t border-white/10">
        <div className="flex items-center gap-2 text-sm">
          <CheckCircle className="h-4 w-4 text-green-400" />
          <span className="text-white/80">Sheets Synced</span>
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={handleLogout}
        className="flex items-center gap-3 px-6 py-4 text-sm font-medium text-white/70 hover:bg-white/10 hover:text-white transition-all border-t border-white/10"
      >
        <LogOut className="h-5 w-5" />
        Logout
      </button>
    </div>
  )
}
