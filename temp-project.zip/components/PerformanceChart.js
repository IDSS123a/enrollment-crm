function PerformanceChart({ data, type }) {
  const chartRef = React.useRef(null);
  const chartInstance = React.useRef(null);

  React.useEffect(() => {
    if (!chartRef.current || !data || data.length === 0) return;

    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    
    if (type === 'revenue') {
      chartInstance.current = new ChartJS(ctx, {
        type: 'bar',
        data: {
          labels: data.map(d => d.month),
          datasets: [
            {
              label: 'Revenue',
              data: data.map(d => d.revenue),
              backgroundColor: 'rgba(99, 102, 241, 0.8)',
              borderRadius: 6,
            },
            {
              label: 'Target',
              data: data.map(d => d.target),
              backgroundColor: 'rgba(16, 185, 129, 0.3)',
              borderRadius: 6,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: true, position: 'top' } },
          scales: { y: { beginAtZero: true } },
        },
      });
    } else if (type === 'funnel') {
      chartInstance.current = new ChartJS(ctx, {
        type: 'bar',
        data: {
          labels: data.map(d => d.stage),
          datasets: [{
            label: 'Count',
            data: data.map(d => d.count),
            backgroundColor: [
              'rgba(99, 102, 241, 0.8)',
              'rgba(139, 92, 246, 0.8)',
              'rgba(168, 85, 247, 0.8)',
              'rgba(192, 132, 252, 0.8)',
              'rgba(16, 185, 129, 0.8)',
            ],
            borderRadius: 6,
          }],
        },
        options: {
          indexAxis: 'y',
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: { x: { beginAtZero: true } },
        },
      });
    }

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, type]);

  try {
    return (
      <div style={{ height: '300px' }} data-name="performance-chart" data-file="components/PerformanceChart.js">
        <canvas ref={chartRef}></canvas>
      </div>
    );
  } catch (error) {
    console.error('PerformanceChart component error:', error);
    return null;
  }
}
