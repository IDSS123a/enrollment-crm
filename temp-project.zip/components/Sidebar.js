"use client"

function Sidebar({ currentPage, onNavigate, onLogout, sheetsConnected, language }) {
  const t = (key, language) => {
    // Placeholder implementation for t function
    // In a real application, this would be replaced with a proper translation function
    const translations = {
      "sidebar.dashboard": { en: "Dashboard", es: "Panel de control" },
      "sidebar.leads": { en: "Leads", es: "Prospectos" },
      "sidebar.analytics": { en: "Analytics", es: "Análisis" },
      "sidebar.campaigns": { en: "Campaigns", es: "Campanas" },
      "sidebar.settings": { en: "Settings", es: "Configuraciones" },
      "sidebar.sheetsSynced": { en: "Google Sheets Synced", es: "Google Sheets Sincronizado" },
      "sidebar.logout": { en: "Logout", es: "Cerrar sesión" },
    }
    return translations[key][language] || key
  }

  try {
    const menuItems = [
      { id: "dashboard", label: t("sidebar.dashboard", language), icon: "layout-dashboard" },
      { id: "leads", label: t("sidebar.leads", language), icon: "users" },
      { id: "analytics", label: t("sidebar.analytics", language), icon: "chart-bar" },
      { id: "campaigns", label: t("sidebar.campaigns", language), icon: "megaphone" },
      { id: "settings", label: t("sidebar.settings", language), icon: "settings" },
    ]

    return (
      <div className="w-64 material-sidebar flex flex-col" data-name="sidebar" data-file="components/Sidebar.js">
        <div className="p-6 border-b border-white/20">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-lg">
              <img
                src="https://i.postimg.cc/zGfMdQfF/IDSS-Logo.png"
                alt="IDSS Logo"
                className="w-8 h-8 object-contain"
              />
            </div>
            <div>
              <h1 className="font-bold text-lg text-white">IDSS CRM</h1>
              <p className="text-xs text-white/70">Campaign Manager</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                currentPage === item.id
                  ? "bg-white/95 text-[var(--primary-color)] shadow-md"
                  : "text-white/90 hover:bg-white/10"
              }`}
            >
              <div className={`icon-${item.icon} text-lg`}></div>
              <span className="font-medium text-sm">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/20 space-y-3">
          {sheetsConnected && (
            <div className="px-3 py-2 bg-white/10 backdrop-blur rounded-lg flex items-center gap-2">
              <div className="icon-database text-sm text-white"></div>
              <span className="text-xs font-medium text-white/90">{t("sidebar.sheetsSynced", language)}</span>
            </div>
          )}
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-white/90 hover:bg-white/10 transition-all duration-200"
          >
            <div className="icon-log-out text-lg"></div>
            <span className="font-medium text-sm">{t("sidebar.logout", language)}</span>
          </button>
        </div>
      </div>
    )
  } catch (error) {
    console.error("Sidebar component error:", error)
    return null
  }
}
