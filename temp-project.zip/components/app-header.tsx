"use client"

import { Bell, User, Globe } from "lucide-react"
import { useState, useEffect } from "react"
import { useAuth } from "@/app/providers"
import { initGoogleSheets } from "@/lib/google-sheets"

export function AppHeader() {
  const { user } = useAuth()
  const [showProfileMenu, setShowProfileMenu] = useState(false)
  const [language, setLanguage] = useState("EN")
  const [theme, setTheme] = useState<"light" | "dark">("light")

  useEffect(() => {
    // Initialize Google Sheets on mount
    initGoogleSheets()

    // Load saved preferences
    if (typeof window !== "undefined") {
      const savedLang = localStorage.getItem("language") || "EN"
      const savedTheme = localStorage.getItem("theme") || "light"
      setLanguage(savedLang)
      setTheme(savedTheme as "light" | "dark")

      if (savedTheme === "dark") {
        document.documentElement.classList.add("dark")
      }
    }
  }, [])

  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light"
    setTheme(newTheme)
    if (typeof window !== "undefined") {
      localStorage.setItem("theme", newTheme)
      if (newTheme === "dark") {
        document.documentElement.classList.add("dark")
      } else {
        document.documentElement.classList.remove("dark")
      }
    }
  }

  const toggleLanguage = () => {
    const newLang = language === "EN" ? "BS" : "EN"
    setLanguage(newLang)
    if (typeof window !== "undefined") {
      localStorage.setItem("language", newLang)
    }
  }

  return (
    <header className="h-16 border-b border-border bg-card shadow-sm">
      <div className="flex h-full items-center justify-between px-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Welcome back, {user?.name || "User"}</h2>
          <p className="text-sm text-muted-foreground">Monitor your enrollment campaigns</p>
        </div>

        <div className="flex items-center gap-4">
          {/* Notifications */}
          <button className="relative rounded-full p-2 hover:bg-muted transition-colors">
            <Bell className="h-5 w-5 text-foreground" />
            <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-destructive" />
          </button>

          {/* Language Toggle */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-2 rounded-lg px-3 py-2 hover:bg-muted transition-colors"
          >
            <Globe className="h-4 w-4 text-foreground" />
            <span className="text-sm font-medium text-foreground">{language}</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="rounded-lg px-3 py-2 text-sm font-medium text-foreground hover:bg-muted transition-colors"
          >
            {theme === "light" ? "🌙" : "☀️"}
          </button>

          {/* Profile Menu */}
          <div className="relative">
            <button
              onClick={() => setShowProfileMenu(!showProfileMenu)}
              className="flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-2 hover:bg-primary/20 transition-colors"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                <User className="h-4 w-4" />
              </div>
              <span className="text-sm font-medium text-foreground">{user?.email}</span>
            </button>

            {showProfileMenu && (
              <div className="absolute right-0 top-12 w-48 rounded-lg bg-card shadow-xl border border-border z-50">
                <div className="p-2">
                  <button
                    onClick={toggleLanguage}
                    className="w-full rounded-md px-3 py-2 text-left text-sm hover:bg-muted transition-colors"
                  >
                    Language: {language}
                  </button>
                  <button
                    onClick={toggleTheme}
                    className="w-full rounded-md px-3 py-2 text-left text-sm hover:bg-muted transition-colors"
                  >
                    {theme === "light" ? "Dark Mode" : "Light Mode"}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
