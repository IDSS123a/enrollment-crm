function StatCard({ title, value, icon, trend }) {
  try {
    const gradients = {
      users: "gradient-primary",
      "trending-up": "gradient-success",
      megaphone: "gradient-info",
      "dollar-sign": "gradient-warning",
    }

    const gradientClass = gradients[icon] || "gradient-primary"

    return (
      <div className="stat-card" data-name="stat-card" data-file="components/StatCard.js">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <h3 className="text-sm font-medium text-[var(--text-secondary)] mb-2 uppercase tracking-wider">{title}</h3>
            <p className="text-3xl font-bold text-[var(--text-primary)] mb-1">{value}</p>
            {trend && (
              <div className="flex items-center gap-1 text-sm font-medium text-[var(--success-color)]">
                <div className="icon-trending-up text-base"></div>
                <span>{trend}</span>
              </div>
            )}
          </div>
          <div className={`w-14 h-14 ${gradientClass} rounded-xl flex items-center justify-center shadow-lg`}>
            <div className={`icon-${icon} text-2xl text-white`}></div>
          </div>
        </div>
      </div>
    )
  } catch (error) {
    console.error("StatCard component error:", error)
    return null
  }
}
