function LeadForm({ lead, onSave, onCancel }) {
  try {
    const [formData, setFormData] = React.useState({
      name: lead?.name || '',
      email: lead?.email || '',
      phone: lead?.phone || '',
      status: lead?.status || 'new',
      source: lead?.source || '',
    });

    const handleSubmit = (e) => {
      e.preventDefault();
      onSave(formData);
    };

    const handleChange = (e) => {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Full Name</label>
          <input type="text" name="name" className="input" value={formData.name} onChange={handleChange} required />
        </div>
        <div>
          <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Email</label>
          <input type="email" name="email" className="input" value={formData.email} onChange={handleChange} required />
        </div>
        <div>
          <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Phone</label>
          <input type="tel" name="phone" className="input" value={formData.phone} onChange={handleChange} />
        </div>
        <div>
          <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Status</label>
          <select name="status" className="input" value={formData.status} onChange={handleChange}>
            <option value="new">New</option>
            <option value="contacted">Contacted</option>
            <option value="qualified">Qualified</option>
            <option value="converted">Converted</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Source</label>
          <input type="text" name="source" className="input" value={formData.source} onChange={handleChange} placeholder="Website, Social Media, etc." />
        </div>
        <div className="flex gap-3 pt-4">
          <button type="submit" className="btn btn-primary flex-1">Save Lead</button>
          <button type="button" onClick={onCancel} className="btn btn-secondary flex-1">Cancel</button>
        </div>
      </form>
    );
  } catch (error) {
    console.error('LeadForm component error:', error);
    return null;
  }
}
