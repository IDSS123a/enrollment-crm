"use client"

import React from "react"

function Header({ sheetsConnected, setSheetsConnected, language, onLanguageChange, theme, onThemeChange }) {
  const [showProfileMenu, setShowProfileMenu] = React.useState(false)
  const userStr = localStorage.getItem("idss_user")
  const user = userStr ? JSON.parse(userStr) : { name: "User", email: "user@example.com" }

  const initGoogleSheets = window.initGoogleSheets // Declare initGoogleSheets variable
  const t = window.t // Declare t variable

  const handleSyncSheets = async () => {
    if (!sheetsConnected) {
      try {
        await initGoogleSheets()
        localStorage.setItem("sheets_connected", "true")
        setSheetsConnected(true)
      } catch (error) {
        console.error("Failed to connect Google Sheets:", error)
      }
    }
  }

  const handleLanguageChange = (lang) => {
    onLanguageChange(lang)
    setShowProfileMenu(false)
  }

  const handleThemeToggle = () => {
    const newTheme = theme === "light" ? "dark" : "light"
    onThemeChange(newTheme)
  }

  const handleLogout = () => {
    localStorage.removeItem("idss_token")
    localStorage.removeItem("idss_user")
    window.location.reload()
  }

  return (
    <header className="material-header px-6 py-4" data-name="header" data-file="components/Header.js">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-medium text-[var(--text-primary)]">
            {t("header.welcome", language)}, {user.name}
          </h2>
          <p className="text-sm text-[var(--text-secondary)] mt-0.5">{t("header.subtitle", language)}</p>
        </div>
        <div className="flex items-center gap-3">
          {!sheetsConnected && (
            <button onClick={handleSyncSheets} className="btn btn-secondary text-xs">
              <div className="icon-database text-base"></div>
              {t("header.connectSheets", language)}
            </button>
          )}
          <button className="relative p-3 hover:bg-gray-100 rounded-lg transition-colors">
            <div className="icon-bell text-xl text-[var(--text-secondary)]"></div>
            <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
          </button>
          <div className="relative">
            <button
              onClick={() => setShowProfileMenu(!showProfileMenu)}
              className="w-10 h-10 gradient-primary rounded-lg flex items-center justify-center shadow-md hover:shadow-lg transition-all"
            >
              <div className="icon-user text-lg text-white"></div>
            </button>
            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-[var(--border-color)] py-2 z-50">
                <div className="px-4 py-3 border-b border-[var(--border-color)]">
                  <p className="font-semibold text-[var(--text-primary)]">{user.name}</p>
                  <p className="text-xs text-[var(--text-secondary)] mt-0.5">{user.email}</p>
                </div>
                <div className="py-1">
                  <div className="px-4 py-3">
                    <p className="text-xs font-semibold text-[var(--text-secondary)] uppercase tracking-wider mb-2">
                      {t("header.language", language)}
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleLanguageChange("BS")}
                        className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                          language === "BS"
                            ? "gradient-primary text-white shadow-md"
                            : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                        }`}
                      >
                        BS
                      </button>
                      <button
                        onClick={() => handleLanguageChange("EN")}
                        className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                          language === "EN"
                            ? "gradient-primary text-white shadow-md"
                            : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                        }`}
                      >
                        EN
                      </button>
                    </div>
                  </div>
                  <button
                    onClick={handleThemeToggle}
                    className="w-full px-4 py-2.5 text-left hover:bg-gray-50 flex items-center gap-3 text-sm text-[var(--text-primary)] transition-colors"
                  >
                    <div className={`icon-${theme === "light" ? "moon" : "sun"} text-lg`}></div>
                    {theme === "light" ? t("header.darkMode", language) : t("header.lightMode", language)}
                  </button>
                  <button
                    onClick={handleLogout}
                    className="w-full px-4 py-2.5 text-left hover:bg-gray-50 flex items-center gap-3 text-sm text-red-600 transition-colors"
                  >
                    <div className="icon-log-out text-lg"></div>
                    {t("header.logout", language)}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
