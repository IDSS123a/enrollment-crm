function AnalyticsCard({ title, data, icon }) {
  try {
    return (
      <div className="card">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
            <div className={`icon-${icon} text-lg text-purple-600`}></div>
          </div>
          <h3 className="text-lg font-semibold text-[var(--text-primary)]">{title}</h3>
        </div>
        <div className="space-y-3">
          {data && data.length > 0 ? (
            data.map((item, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-sm text-[var(--text-secondary)]">{item.label}</span>
                <span className="text-sm font-semibold text-[var(--text-primary)]">{item.value}</span>
              </div>
            ))
          ) : (
            <p className="text-sm text-[var(--text-secondary)]">No data available</p>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('AnalyticsCard component error:', error);
    return null;
  }
}
