function ActivityFeed({ activities }) {
  try {
    if (!activities || activities.length === 0) {
      return <p className="text-sm text-[var(--text-secondary)] text-center py-4">No recent activities</p>;
    }

    return (
      <div className="space-y-4">
        {activities.map((activity, index) => (
          <div key={index} className="flex gap-3 pb-4 border-b border-[var(--border-color)] last:border-0">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              activity.type === 'lead' ? 'bg-blue-100' : 
              activity.type === 'conversion' ? 'bg-green-100' : 'bg-purple-100'
            }`}>
              <div className={`icon-${activity.icon} text-sm ${
                activity.type === 'lead' ? 'text-blue-600' : 
                activity.type === 'conversion' ? 'text-green-600' : 'text-purple-600'
              }`}></div>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-[var(--text-primary)]">{activity.title}</p>
              <p className="text-xs text-[var(--text-secondary)] mt-1">{activity.time}</p>
            </div>
          </div>
        ))}
      </div>
    );
  } catch (error) {
    console.error('ActivityFeed component error:', error);
    return null;
  }
}
