async function apiLogin(credentials) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (credentials.email === 'admin@idss.ba' && credentials.password === 'password123') {
        resolve({
          token: 'mock_jwt_token_' + Date.now(),
          user: {
            id: 1,
            email: 'admin@idss.ba',
            name: 'Admin User',
            role: 'admin',
          },
        });
      } else if (credentials.email === 'lamia@idss.ba' && credentials.password === 'lamia123') {
        resolve({
          token: 'mock_jwt_token_' + Date.now(),
          user: {
            id: 2,
            email: 'lamia@idss.ba',
            name: 'Lamia',
            role: 'admin',
          },
        });
      } else {
        reject(new Error('Invalid credentials'));
      }
    }, 800);
  });
}

async function apiGetDashboard() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        totalLeads: 1247,
        conversionRate: 3.2,
        activeCampaigns: 8,
        revenue: 45230,
        chartData: [
          { name: 'Jan', leads: 400, conversions: 12 },
          { name: 'Feb', leads: 300, conversions: 16 },
          { name: 'Mar', leads: 200, conversions: 8 },
          { name: 'Apr', leads: 278, conversions: 18 },
          { name: 'May', leads: 189, conversions: 10 },
          { name: 'Jun', leads: 239, conversions: 15 },
        ],
        leadSources: [
          { label: 'Website', value: '45%' },
          { label: 'Social Media', value: '28%' },
          { label: 'Referral', value: '18%' },
          { label: 'Email', value: '9%' },
        ],
        conversionFunnel: [
          { label: 'Leads', value: '1,247' },
          { label: 'Contacted', value: '856' },
          { label: 'Qualified', value: '423' },
          { label: 'Converted', value: '156' },
        ],
        topPerformers: [
          { label: 'Campaign A', value: '234' },
          { label: 'Campaign B', value: '187' },
          { label: 'Campaign C', value: '142' },
        ],
      });
    }, 500);
  });
}

async function apiGetActivities() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        { type: 'lead', icon: 'user-plus', title: 'New lead added', time: '5 minutes ago' },
        { type: 'conversion', icon: 'check-circle', title: 'Lead converted to customer', time: '1 hour ago' },
        { type: 'campaign', icon: 'megaphone', title: 'Campaign launched', time: '3 hours ago' },
        { type: 'lead', icon: 'user-plus', title: 'New lead from website', time: '5 hours ago' },
      ]);
    }, 300);
  });
}

async function apiCreateLead(leadData) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ id: Date.now(), ...leadData });
    }, 500);
  });
}

async function apiUpdateLead(leadId, leadData) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ id: leadId, ...leadData });
    }, 500);
  });
}

async function apiDeleteLead(leadId) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true });
    }, 500);
  });
}

async function apiGetLeads() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        { id: 1, name: 'John Doe', email: 'john@example.com', phone: '+387 61 123 456', status: 'new', source: 'Website' },
        { id: 2, name: 'Jane Smith', email: 'jane@example.com', phone: '+387 61 234 567', status: 'contacted', source: 'Referral' },
        { id: 3, name: 'Mike Johnson', email: 'mike@example.com', phone: '+387 61 345 678', status: 'qualified', source: 'Social Media' },
        { id: 4, name: 'Sarah Williams', email: 'sarah@example.com', phone: '+387 61 456 789', status: 'converted', source: 'Email Campaign' },
        { id: 5, name: 'David Brown', email: 'david@example.com', phone: '+387 61 567 890', status: 'new', source: 'Website' },
        { id: 6, name: 'Emily Davis', email: 'emily@example.com', phone: '+387 61 678 901', status: 'contacted', source: 'Social Media' },
        { id: 7, name: 'Chris Wilson', email: 'chris@example.com', phone: '+387 61 789 012', status: 'qualified', source: 'Referral' },
        { id: 8, name: 'Anna Martinez', email: 'anna@example.com', phone: '+387 61 890 123', status: 'rejected', source: 'Cold Call' },
      ]);
    }, 500);
  });
}

async function apiGetAnalytics(timeRange) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        totalRevenue: 245680,
        avgDealSize: 3850,
        winRate: 32.5,
        salesCycle: 18,
        revenueData: [
          { month: 'Jul', revenue: 35000, target: 40000 },
          { month: 'Aug', revenue: 42000, target: 40000 },
          { month: 'Sep', revenue: 38000, target: 45000 },
          { month: 'Oct', revenue: 48000, target: 45000 },
          { month: 'Nov', revenue: 52000, target: 50000 },
          { month: 'Dec', revenue: 30680, target: 50000 },
        ],
        funnelData: [
          { stage: 'Leads', count: 1247, percentage: 100 },
          { stage: 'Qualified', count: 856, percentage: 68.6 },
          { stage: 'Proposal', count: 423, percentage: 33.9 },
          { stage: 'Negotiation', count: 234, percentage: 18.8 },
          { stage: 'Closed', count: 156, percentage: 12.5 },
        ],
        sourcePerformance: [
          { name: 'Website', icon: 'globe', leads: 458, revenue: 98500, conversion: 35.2 },
          { name: 'Social Media', icon: 'share-2', leads: 342, revenue: 72300, conversion: 28.4 },
          { name: 'Email Campaign', icon: 'mail', leads: 287, revenue: 54200, conversion: 24.8 },
          { name: 'Referral', icon: 'users', leads: 160, revenue: 20680, conversion: 18.5 },
        ],
        campaignROI: [
          { name: 'Summer Enrollment 2024', spent: 12000, revenue: 45000, roi: 275 },
          { name: 'Fall Program Launch', spent: 8500, revenue: 28000, roi: 229 },
          { name: 'Social Media Boost', spent: 5000, revenue: 15200, roi: 204 },
          { name: 'Email Newsletter', spent: 3200, revenue: 8900, roi: 178 },
        ],
        topPerformers: [
          { name: 'Sarah Johnson', deals: 42, revenue: 89400 },
          { name: 'Michael Chen', deals: 38, revenue: 76200 },
          { name: 'Emma Wilson', deals: 35, revenue: 68500 },
          { name: 'David Martinez', deals: 31, revenue: 54800 },
        ],
      });
    }, 600);
  });
}

async function apiGetCampaigns() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        { 
          id: 1, 
          name: 'Summer Enrollment 2025', 
          status: 'active',
          budget: 15000,
          spent: 8500,
          leads: 342,
          conversions: 89,
          revenue: 56800,
          startDate: '2025-06-01',
          endDate: '2025-08-31',
          channels: ['Social Media', 'Email', 'Website'],
          description: 'Comprehensive summer enrollment campaign targeting high school graduates'
        },
        { 
          id: 2, 
          name: 'Fall Program Launch', 
          status: 'active',
          budget: 12000,
          spent: 9200,
          leads: 287,
          conversions: 67,
          revenue: 42300,
          startDate: '2025-09-01',
          endDate: '2025-11-30',
          channels: ['Website', 'Referral'],
          description: 'Launch campaign for new fall programs and courses'
        },
        { 
          id: 3, 
          name: 'Spring Open House', 
          status: 'paused',
          budget: 8000,
          spent: 3500,
          leads: 156,
          conversions: 34,
          revenue: 18900,
          startDate: '2025-03-01',
          endDate: '2025-05-31',
          channels: ['Social Media', 'Local Ads'],
          description: 'Virtual and in-person open house events for prospective students'
        },
        { 
          id: 4, 
          name: 'Winter Scholarship Program', 
          status: 'completed',
          budget: 10000,
          spent: 10000,
          leads: 423,
          conversions: 112,
          revenue: 67500,
          startDate: '2024-12-01',
          endDate: '2025-02-28',
          channels: ['Email', 'Website', 'Social Media'],
          description: 'Scholarship awareness campaign for winter semester enrollments'
        },
      ]);
    }, 500);
  });
}

async function apiCreateCampaign(campaignData) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ id: Date.now(), ...campaignData, leads: 0, conversions: 0, revenue: 0, spent: 0 });
    }, 500);
  });
}

async function apiUpdateCampaign(campaignId, campaignData) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ id: campaignId, ...campaignData });
    }, 500);
  });
}

async function apiDeleteCampaign(campaignId) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true });
    }, 500);
  });
}
