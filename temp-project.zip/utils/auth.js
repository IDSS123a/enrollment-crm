const AUTH_TOKEN_KEY = 'idss_token';
const AUTH_USER_KEY = 'idss_user';

function getAuthToken() {
  return localStorage.getItem(AUTH_TOKEN_KEY);
}

function isAuthenticated() {
  return !!getAuthToken();
}

function getAuthHeaders() {
  const token = getAuthToken();
  return {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` }),
  };
}
