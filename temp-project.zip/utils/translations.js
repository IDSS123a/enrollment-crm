const translations = {
  EN: {
    header: {
      welcome: 'Welcome back',
      subtitle: 'Monitor your enrollment campaigns',
      connectSheets: 'Connect Sheets',
      language: 'Language',
      darkMode: 'Dark Mode',
      lightMode: 'Light Mode',
      logout: 'Logout'
    },
    sidebar: {
      dashboard: 'Dashboard',
      leads: 'Leads',
      analytics: 'Analytics',
      campaigns: 'Campaigns',
      settings: 'Settings',
      sheetsSynced: 'Sheets Synced',
      logout: 'Logout'
    },
    dashboard: {
      title: 'Dashboard Overview',
      totalLeads: 'Total Leads',
      conversionRate: 'Conversion Rate',
      activeCampaigns: 'Active Campaigns',
      revenue: 'Revenue',
      performanceTrends: 'Performance Trends',
      recentActivity: 'Recent Activity'
    }
  },
  BS: {
    header: {
      welcome: 'Dobrodošli',
      subtitle: 'Pratite svoje kampanje upisa',
      connectSheets: 'Poveži Sheets',
      language: 'Jezik',
      darkMode: 'Tamni Režim',
      lightMode: 'Svijetli Režim',
      logout: 'Odjava'
    },
    sidebar: {
      dashboard: 'Kontrolna Tabla',
      leads: 'Potencijalni Kandidati',
      analytics: 'Analitika',
      campaigns: 'Kampanje',
      settings: 'Postavke',
      sheetsSynced: 'Sheets Sinhronizovan',
      logout: 'Odjava'
    },
    dashboard: {
      title: 'Pregled Kontrolne Table',
      totalLeads: 'Ukupno Kandidata',
      conversionRate: 'Stopa Konverzije',
      activeCampaigns: 'Aktivne Kampanje',
      revenue: 'Prihod',
      performanceTrends: 'Trendovi Performansi',
      recentActivity: 'Nedavne Aktivnosti'
    }
  }
};

function t(key, language = 'EN') {
  const keys = key.split('.');
  let value = translations[language];
  
  for (const k of keys) {
    if (value && typeof value === 'object') {
      value = value[k];
    } else {
      return key;
    }
  }
  
  return value || key;
}
