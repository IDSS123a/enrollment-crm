# Google Apps Script - Complete Code with Delete Function

Replace your entire Google Apps Script code with this:

\`\`\`javascript
function doPost(e) {
  try {
    var sheet = SpreadsheetApp.openById('1IMc5T_rB9w9j84P7kXS6bI_SHAFHQt5UF0M2wZz0C9o').getActiveSheet();
    var data = JSON.parse(e.postData.contents);
    
    // Check if this is a delete action
    if (data.action === 'delete' && data.email) {
      var dataRange = sheet.getDataRange();
      var values = dataRange.getValues();
      
      // Find and delete the row with matching email
      for (var i = values.length - 1; i >= 1; i--) { // Start from bottom, skip header
        if (values[i][3] === data.email) { // Column 4 is email (index 3)
          sheet.deleteRow(i + 1);
          return ContentService.createTextOutput(JSON.stringify({
            success: true,
            message: 'Lead deleted'
          })).setMimeType(ContentService.MimeType.JSON);
        }
      }
      
      return ContentService.createTextOutput(JSON.stringify({
        success: false,
        message: 'Email not found'
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    // Add new lead
    sheet.appendRow([
      data.date,
      data.time,
      data.name,
      data.email,
      data.phone,
      data.status,
      data.source
    ]);
    
    return ContentService.createTextOutput(JSON.stringify({success: true}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false, 
      error: error.toString()
    }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  try {
    var sheet = SpreadsheetApp.openById('1IMc5T_rB9w9j84P7kXS6bI_SHAFHQt5UF0M2wZz0C9o').getActiveSheet();
    var data = sheet.getDataRange().getValues();
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      values: data
    }))
    .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false, 
      error: error.toString()
    }))
    .setMimeType(ContentService.MimeType.JSON);
  }
}
\`\`\`

## Important Steps:

1. Copy the entire code above
2. Open your Google Apps Script editor
3. **Delete ALL existing code**
4. Paste the new code
5. Click **Save** (disk icon)
6. Go to **Deploy > Manage deployments**
7. Click the edit icon (pencil) on your existing deployment
8. Click **New Version**
9. Click **Deploy**
10. The URL will remain the same, but the functionality will be updated

## What This Fixes:

- Properly handles delete requests by searching for email in the sheet
- Deletes the entire row when a matching email is found
- Returns success/error messages for better debugging
- Maintains add functionality for new leads
