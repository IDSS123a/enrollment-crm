# Google Sheets Integration Setup Guide

## Spreadsheet Information
- **Spreadsheet ID**: `1IMc5T_rB9w9j84P7kXS6bI_SHAFHQt5UF0M2wZz0C9o`
- **Sheet URL**: https://docs.google.com/spreadsheets/d/1IMc5T_rB9w9j84P7kXS6bI_SHAFHQt5UF0M2wZz0C9o/edit

## Required Columns
The spreadsheet must have these columns in order:
1. Date
2. Time
3. Name
4. Email
5. Phone
6. Status
7. Source

## Setup Instructions

### Step 1: Create Google Apps Script
1. Open your Google Sheet
2. Click **Extensions > Apps Script**
3. Delete any existing code
4. Copy and paste this code:

\`\`\`javascript
function doPost(e) {
  try {
    var sheet = SpreadsheetApp.openById('1IMc5T_rB9w9j84P7kXS6bI_SHAFHQt5UF0M2wZz0C9o').getActiveSheet();
    var data = JSON.parse(e.postData.contents);
    
    sheet.appendRow([
      data.date,
      data.time,
      data.name,
      data.email,
      data.phone,
      data.status,
      data.source
    ]);
    
    return ContentService.createTextOutput(JSON.stringify({success: true}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({success: false, error: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
\`\`\`

5. Click **Save** (disk icon)

### Step 2: Deploy as Web App
1. Click **Deploy > New deployment**
2. Click gear icon next to "Select type" and choose **Web app**
3. Configure:
   - Description: "IDSS CRM Lead Sync"
   - Execute as: **Me**
   - Who has access: **Anyone**
4. Click **Deploy**
5. Click **Authorize access** and grant permissions
6. Copy the **Web App URL** (looks like: https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec)

### Step 3: Configure in CRM
1. Go to **Settings** in the CRM
2. Paste the Web App URL in the "Web App URL Configuration" section
3. Click **Save Web App URL**
4. Click **Connect Google Sheets**

### Step 4: Test
1. Go to **Leads** page
2. Click **Add New Lead**
3. Fill in the form and save
4. Check your Google Sheet - the new lead should appear automatically

## Troubleshooting

### Leads not appearing in sheet
- Verify the Web App URL is correct
- Check that the script is deployed with "Anyone" access
- Ensure columns in sheet match required format
- Check browser console for error messages

### Permission errors
- Re-authorize the Apps Script
- Make sure you're the sheet owner or have edit access
- Redeploy the Web App with correct permissions

## Current Status
- Integration ready for deployment
- Web App URL needs to be configured by user
- Manual sync available via console logging
