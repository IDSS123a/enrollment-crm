# Google Apps Script - GET Endpoint Setup

To enable reading data from Google Sheets, update your Google Apps Script with the following code:

\`\`\`javascript
function doPost(e) {
  try {
    var sheet = SpreadsheetApp.openById('1IMc5T_rB9w9j84P7kXS6bI_SHAFHQt5UF0M2wZz0C9o').getActiveSheet();
    var data = JSON.parse(e.postData.contents);
    
    sheet.appendRow([
      data.date,
      data.time,
      data.name,
      data.email,
      data.phone,
      data.status,
      data.source
    ]);
    
    return ContentService.createTextOutput(JSON.stringify({success: true}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({success: false, error: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  try {
    var sheet = SpreadsheetApp.openById('1IMc5T_rB9w9j84P7kXS6bI_SHAFHQt5UF0M2wZz0C9o').getActiveSheet();
    var data = sheet.getDataRange().getValues();
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      values: data
    }))
    .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false, 
      error: error.toString()
    }))
    .setMimeType(ContentService.MimeType.JSON);
  }
}
\`\`\`

## Important Notes

1. After updating the script, you need to **create a new deployment**
2. Go to **Deploy > Manage deployments**
3. Click the edit icon (pencil) on your existing deployment
4. Click **New Version** 
5. Save and get the new Web App URL
6. Update the Web App URL in CRM Settings if it changed

This will enable both:
- POST requests (to add new leads)
- GET requests (to retrieve existing leads)
