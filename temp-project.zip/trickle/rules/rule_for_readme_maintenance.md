When making significant updates to the project

- Check if the README.md in trickle/notes needs to be updated
- Update the README.md if:
  - New features are added
  - Major components are modified
  - Technology stack changes
  - User workflows change
  - Demo credentials change
- Always update the "Last Updated" date in README.md when making changes
- Keep the README concise and focused on key information
