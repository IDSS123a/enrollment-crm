"use client"

import { useState, useEffect } from "react"
import { ExternalLink, CheckCircle, XCircle, RefreshCw } from "lucide-react"
import { AppLayout } from "@/components/app-layout"
import { MaterialCard } from "@/components/material-card"
import { AlertMessage } from "@/components/alert-message"
import { initGoogleSheets, SHEET_URL } from "@/lib/google-sheets"

export default function SettingsPage() {
  const [webAppUrl, setWebAppUrl] = useState("")
  const [isConnected, setIsConnected] = useState(false)
  const [testing, setTesting] = useState(false)
  const [alert, setAlert] = useState<{ type: "success" | "error"; message: string } | null>(null)

  useEffect(() => {
    // Load saved Web App URL
    if (typeof window !== "undefined") {
      const savedUrl = localStorage.getItem("sheets_web_app_url")
      const connected = localStorage.getItem("sheets_connected") === "true"
      if (savedUrl) setWebAppUrl(savedUrl)
      setIsConnected(connected)
    }
  }, [])

  async function handleTestConnection() {
    setTesting(true)
    setAlert(null)

    try {
      await initGoogleSheets()
      setIsConnected(true)
      if (webAppUrl && typeof window !== "undefined") {
        localStorage.setItem("sheets_web_app_url", webAppUrl)
      }
      setAlert({ type: "success", message: "Successfully connected to Google Sheets" })
    } catch (error) {
      setIsConnected(false)
      setAlert({ type: "error", message: "Failed to connect to Google Sheets" })
    } finally {
      setTesting(false)
    }
  }

  return (
    <AppLayout>
      <div className="space-y-6 max-w-4xl">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Settings</h1>
          <p className="text-sm text-muted-foreground">Manage your Google Sheets integration and preferences</p>
        </div>

        {alert && <AlertMessage type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}

        {/* Google Sheets Integration */}
        <MaterialCard>
          <div className="flex items-start gap-4 mb-6">
            <div className="flex-1">
              <h2 className="text-lg font-semibold text-foreground mb-1">Google Sheets Integration</h2>
              <p className="text-sm text-muted-foreground">
                Connect your CRM to Google Sheets for automatic lead synchronization
              </p>
            </div>
            <div className="flex items-center gap-2">
              {isConnected ? (
                <>
                  <CheckCircle className="h-5 w-5 text-success" />
                  <span className="text-sm font-medium text-success">Connected</span>
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5 text-destructive" />
                  <span className="text-sm font-medium text-destructive">Not Connected</span>
                </>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Google Apps Script Web App URL</label>
              <input
                type="url"
                value={webAppUrl}
                onChange={(e) => setWebAppUrl(e.target.value)}
                placeholder="https://script.google.com/macros/s/..."
                className="w-full px-4 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              />
              <p className="text-xs text-muted-foreground mt-2">
                Enter the Web App URL from your deployed Google Apps Script
              </p>
            </div>

            <button
              onClick={handleTestConnection}
              disabled={testing}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {testing ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Testing Connection...
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4" />
                  Test Connection
                </>
              )}
            </button>
          </div>
        </MaterialCard>

        {/* Spreadsheet Info */}
        <MaterialCard>
          <h2 className="text-lg font-semibold text-foreground mb-4">Spreadsheet Information</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-sm text-muted-foreground">Spreadsheet URL</span>
              <a
                href={SHEET_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-sm text-primary hover:underline"
              >
                Open Spreadsheet
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-sm text-muted-foreground">Required Columns</span>
              <span className="text-sm font-mono text-foreground">
                Date | Time | Name | Email | Phone | Status | Source
              </span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-muted-foreground">Sync Status</span>
              <span className="text-sm font-medium text-foreground">
                {isConnected ? "Auto-sync enabled" : "Disconnected"}
              </span>
            </div>
          </div>
        </MaterialCard>

        {/* Setup Instructions */}
        <MaterialCard>
          <h2 className="text-lg font-semibold text-foreground mb-4">Setup Instructions</h2>
          <ol className="space-y-3 text-sm text-foreground">
            <li className="flex gap-3">
              <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold">
                1
              </span>
              <span>Open your Google Sheet and go to Extensions &gt; Apps Script</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold">
                2
              </span>
              <span>Copy the Apps Script code from the documentation and paste it into the editor</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold">
                3
              </span>
              <span>Deploy the script as a Web App with "Anyone" access</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold">
                4
              </span>
              <span>Copy the Web App URL and paste it in the field above</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold">
                5
              </span>
              <span>Click "Test Connection" to verify the integration</span>
            </li>
          </ol>
        </MaterialCard>
      </div>
    </AppLayout>
  )
}
