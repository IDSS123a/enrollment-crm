"use client"

import { useEffect, useState } from "react"
import { Users, TrendingUp, Megaphone, DollarSign, UserPlus, CheckCircle, CameraIcon as Campaign } from "lucide-react"
import { AppLayout } from "@/components/app-layout"
import { StatCard, MaterialCard } from "@/components/material-card"
import { LoadingSpinner } from "@/components/loading-spinner"
import { apiGetDashboard, apiGetActivities, type DashboardData, type Activity } from "@/lib/api"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [activities, setActivities] = useState<Activity[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadData() {
      try {
        const [dashboardData, activitiesData] = await Promise.all([apiGetDashboard(), apiGetActivities()])
        setData(dashboardData)
        setActivities(activitiesData)
      } catch (error) {
        console.error("Failed to load dashboard data:", error)
      } finally {
        setLoading(false)
      }
    }
    loadData()
  }, [])

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <LoadingSpinner size="lg" />
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Stats Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Leads"
            value={data?.totalLeads.toLocaleString() || "0"}
            icon={<Users className="h-6 w-6 text-primary" />}
            trend={{ value: "12.5%", positive: true }}
          />
          <StatCard
            title="Conversion Rate"
            value={`${data?.conversionRate}%` || "0%"}
            icon={<TrendingUp className="h-6 w-6 text-secondary" />}
            trend={{ value: "2.1%", positive: true }}
            gradient
          />
          <StatCard
            title="Active Campaigns"
            value={data?.activeCampaigns || "0"}
            icon={<Megaphone className="h-6 w-6 text-accent" />}
          />
          <StatCard
            title="Revenue"
            value={`$${data?.revenue.toLocaleString()}` || "$0"}
            icon={<DollarSign className="h-6 w-6 text-success" />}
            trend={{ value: "8.3%", positive: true }}
            gradient
          />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Performance Trends Chart */}
          <MaterialCard className="lg:col-span-2">
            <h3 className="text-lg font-semibold text-foreground mb-4">Performance Trends</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={data?.chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.5rem",
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="leads" stroke="hsl(var(--primary))" strokeWidth={2} />
                <Line type="monotone" dataKey="conversions" stroke="hsl(var(--secondary))" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </MaterialCard>

          {/* Recent Activity */}
          <MaterialCard>
            <h3 className="text-lg font-semibold text-foreground mb-4">Recent Activity</h3>
            <div className="space-y-4">
              {activities.map((activity, index) => {
                const iconMap: Record<string, any> = {
                  "user-plus": UserPlus,
                  "check-circle": CheckCircle,
                  megaphone: Campaign,
                }
                const Icon = iconMap[activity.icon] || UserPlus

                return (
                  <div key={index} className="flex items-start gap-3">
                    <div className="rounded-full bg-primary/10 p-2">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground">{activity.title}</p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </MaterialCard>
        </div>

        {/* Additional Metrics */}
        <div className="grid gap-6 md:grid-cols-2">
          <MaterialCard>
            <h3 className="text-lg font-semibold text-foreground mb-4">Lead Sources</h3>
            <div className="space-y-3">
              {data?.leadSources.map((source, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm text-foreground">{source.label}</span>
                  <span className="text-sm font-semibold text-primary">{source.value}</span>
                </div>
              ))}
            </div>
          </MaterialCard>

          <MaterialCard>
            <h3 className="text-lg font-semibold text-foreground mb-4">Top Performers</h3>
            <div className="space-y-3">
              {data?.topPerformers.map((performer, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm text-foreground">{performer.label}</span>
                  <span className="text-sm font-semibold text-secondary">{performer.value}</span>
                </div>
              ))}
            </div>
          </MaterialCard>
        </div>
      </div>
    </AppLayout>
  )
}
