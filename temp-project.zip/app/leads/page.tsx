"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Plus, Search, Edit2, Trash2, Download } from "lucide-react"
import { AppLayout } from "@/components/app-layout"
import { MaterialCard } from "@/components/material-card"
import { ModalDialog } from "@/components/modal-dialog"
import { AlertMessage } from "@/components/alert-message"
import { LoadingSpinner } from "@/components/loading-spinner"
import { apiGetLeads, apiCreateLead, apiUpdateLead, apiDeleteLead, type Lead } from "@/lib/api"
import { syncToGoogleSheets, deleteFromGoogleSheets, loadFromGoogleSheets } from "@/lib/google-sheets"
import { cn } from "@/lib/cn"

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([])
  const [filteredLeads, setFilteredLeads] = useState<Lead[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingLead, setEditingLead] = useState<Lead | null>(null)
  const [alert, setAlert] = useState<{ type: "success" | "error"; message: string } | null>(null)

  useEffect(() => {
    loadLeads()
  }, [])

  useEffect(() => {
    if (searchQuery) {
      const filtered = leads.filter(
        (lead) =>
          lead.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          lead.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
          lead.phone.includes(searchQuery),
      )
      setFilteredLeads(filtered)
    } else {
      setFilteredLeads(leads)
    }
  }, [searchQuery, leads])

  async function loadLeads() {
    try {
      setLoading(true)
      const [apiLeads, sheetLeads] = await Promise.all([apiGetLeads(), loadFromGoogleSheets()])

      // Merge API leads with Google Sheets leads
      const allLeads = [...apiLeads]
      sheetLeads.forEach((sheetLead) => {
        if (!allLeads.find((lead) => lead.email === sheetLead.email)) {
          allLeads.push(sheetLead)
        }
      })

      setLeads(allLeads)
      setFilteredLeads(allLeads)
    } catch (error) {
      console.error("Failed to load leads:", error)
      setAlert({ type: "error", message: "Failed to load leads" })
    } finally {
      setLoading(false)
    }
  }

  function openCreateModal() {
    setEditingLead(null)
    setIsModalOpen(true)
  }

  function openEditModal(lead: Lead) {
    setEditingLead(lead)
    setIsModalOpen(true)
  }

  async function handleDelete(lead: Lead) {
    if (!confirm(`Are you sure you want to delete ${lead.name}?`)) return

    try {
      await apiDeleteLead(lead.id)

      // Delete from Google Sheets
      try {
        await deleteFromGoogleSheets(lead.email)
      } catch (error) {
        console.error("Failed to delete from Google Sheets:", error)
      }

      setLeads(leads.filter((l) => l.id !== lead.id))
      setAlert({ type: "success", message: "Lead deleted successfully" })
    } catch (error) {
      console.error("Failed to delete lead:", error)
      setAlert({ type: "error", message: "Failed to delete lead" })
    }
  }

  const statusColors: Record<Lead["status"], string> = {
    new: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
    contacted: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300",
    qualified: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300",
    converted: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
    rejected: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
  }

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <LoadingSpinner size="lg" />
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Leads Management</h1>
            <p className="text-sm text-muted-foreground">{leads.length} total leads</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={loadLeads}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/90 transition-colors"
            >
              <Download className="h-4 w-4" />
              Sync from Sheets
            </button>
            <button
              onClick={openCreateModal}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            >
              <Plus className="h-4 w-4" />
              Add Lead
            </button>
          </div>
        </div>

        {/* Alert */}
        {alert && <AlertMessage type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}

        {/* Search */}
        <MaterialCard>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search leads by name, email, or phone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        </MaterialCard>

        {/* Leads Table */}
        <MaterialCard className="overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Phone
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Source
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredLeads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-foreground">{lead.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{lead.email}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{lead.phone}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={cn(
                          "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
                          statusColors[lead.status],
                        )}
                      >
                        {lead.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{lead.source}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => openEditModal(lead)}
                          className="p-2 rounded-lg hover:bg-muted transition-colors"
                        >
                          <Edit2 className="h-4 w-4 text-primary" />
                        </button>
                        <button
                          onClick={() => handleDelete(lead)}
                          className="p-2 rounded-lg hover:bg-muted transition-colors"
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </MaterialCard>

        {/* Lead Form Modal */}
        <ModalDialog
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title={editingLead ? "Edit Lead" : "Add New Lead"}
        >
          <LeadForm
            lead={editingLead}
            onSubmit={async (leadData) => {
              try {
                if (editingLead) {
                  await apiUpdateLead(editingLead.id, leadData)
                  setLeads(leads.map((l) => (l.id === editingLead.id ? { ...l, ...leadData } : l)))
                  setAlert({ type: "success", message: "Lead updated successfully" })
                } else {
                  const newLead = await apiCreateLead(leadData)
                  setLeads([...leads, newLead])

                  // Sync to Google Sheets
                  try {
                    await syncToGoogleSheets(newLead)
                  } catch (error) {
                    console.error("Failed to sync to Google Sheets:", error)
                  }

                  setAlert({ type: "success", message: "Lead created successfully" })
                }
                setIsModalOpen(false)
              } catch (error) {
                console.error("Failed to save lead:", error)
                setAlert({ type: "error", message: "Failed to save lead" })
              }
            }}
            onCancel={() => setIsModalOpen(false)}
          />
        </ModalDialog>
      </div>
    </AppLayout>
  )
}

function LeadForm({
  lead,
  onSubmit,
  onCancel,
}: {
  lead: Lead | null
  onSubmit: (data: Partial<Lead>) => void
  onCancel: () => void
}) {
  const [formData, setFormData] = useState<Partial<Lead>>(
    lead || {
      name: "",
      email: "",
      phone: "",
      status: "new",
      source: "",
    },
  )

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Name *</label>
        <input
          type="text"
          required
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Email *</label>
        <input
          type="email"
          required
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Phone *</label>
        <input
          type="tel"
          required
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Status *</label>
        <select
          required
          value={formData.status}
          onChange={(e) => setFormData({ ...formData, status: e.target.value as Lead["status"] })}
          className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        >
          <option value="new">New</option>
          <option value="contacted">Contacted</option>
          <option value="qualified">Qualified</option>
          <option value="converted">Converted</option>
          <option value="rejected">Rejected</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-1">Source</label>
        <input
          type="text"
          value={formData.source}
          onChange={(e) => setFormData({ ...formData, source: e.target.value })}
          className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
      </div>

      <div className="flex gap-3 pt-4">
        <button
          type="submit"
          className="flex-1 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors font-medium"
        >
          {lead ? "Update Lead" : "Create Lead"}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 rounded-lg bg-muted text-foreground hover:bg-muted/80 transition-colors font-medium"
        >
          Cancel
        </button>
      </div>
    </form>
  )
}
