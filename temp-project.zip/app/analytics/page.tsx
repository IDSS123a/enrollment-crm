"use client"

import { useEffect, useState } from "react"
import { DollarSign, TrendingUp, Award, Clock, Globe, Share2, Mail, UsersIcon } from "lucide-react"
import { AppLayout } from "@/components/app-layout"
import { StatCard, MaterialCard } from "@/components/material-card"
import { LoadingSpinner } from "@/components/loading-spinner"
import { apiGetAnalytics, type AnalyticsData } from "@/lib/api"
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null)
  const [timeRange, setTimeRange] = useState("30d")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadData() {
      try {
        const analyticsData = await apiGetAnalytics(timeRange)
        setData(analyticsData)
      } catch (error) {
        console.error("Failed to load analytics data:", error)
      } finally {
        setLoading(false)
      }
    }
    loadData()
  }, [timeRange])

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <LoadingSpinner size="lg" />
        </div>
      </AppLayout>
    )
  }

  const iconMap: Record<string, any> = {
    globe: Globe,
    "share-2": Share2,
    mail: Mail,
    users: UsersIcon,
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header with Time Range Filter */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground">Analytics Overview</h1>
          <div className="flex gap-2">
            {["7d", "30d", "90d", "1y"].map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  timeRange === range ? "bg-primary text-primary-foreground" : "bg-card text-foreground hover:bg-muted"
                }`}
              >
                {range}
              </button>
            ))}
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Revenue"
            value={`$${data?.totalRevenue.toLocaleString()}`}
            icon={<DollarSign className="h-6 w-6 text-primary" />}
            gradient
          />
          <StatCard
            title="Avg Deal Size"
            value={`$${data?.avgDealSize.toLocaleString()}`}
            icon={<TrendingUp className="h-6 w-6 text-secondary" />}
          />
          <StatCard
            title="Win Rate"
            value={`${data?.winRate}%`}
            icon={<Award className="h-6 w-6 text-accent" />}
            gradient
          />
          <StatCard
            title="Sales Cycle"
            value={`${data?.salesCycle} days`}
            icon={<Clock className="h-6 w-6 text-success" />}
          />
        </div>

        {/* Revenue Chart */}
        <MaterialCard>
          <h3 className="text-lg font-semibold text-foreground mb-4">Revenue vs Target</h3>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={data?.revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
              <YAxis stroke="hsl(var(--muted-foreground))" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                }}
              />
              <Legend />
              <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
              <Bar dataKey="target" fill="hsl(var(--secondary))" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </MaterialCard>

        {/* Conversion Funnel & Source Performance */}
        <div className="grid gap-6 lg:grid-cols-2">
          <MaterialCard>
            <h3 className="text-lg font-semibold text-foreground mb-4">Conversion Funnel</h3>
            <div className="space-y-3">
              {data?.funnelData.map((stage, index) => (
                <div key={index}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-foreground">{stage.stage}</span>
                    <span className="text-sm text-muted-foreground">{stage.count.toLocaleString()}</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-primary to-secondary transition-all"
                      style={{ width: `${stage.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </MaterialCard>

          <MaterialCard>
            <h3 className="text-lg font-semibold text-foreground mb-4">Source Performance</h3>
            <div className="space-y-4">
              {data?.sourcePerformance.map((source, index) => {
                const Icon = iconMap[source.icon] || Globe
                return (
                  <div key={index} className="flex items-center gap-3">
                    <div className="rounded-full bg-primary/10 p-2">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground">{source.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {source.leads} leads · ${source.revenue.toLocaleString()} · {source.conversion}%
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          </MaterialCard>
        </div>

        {/* Campaign ROI & Top Performers */}
        <div className="grid gap-6 lg:grid-cols-2">
          <MaterialCard>
            <h3 className="text-lg font-semibold text-foreground mb-4">Campaign ROI</h3>
            <div className="space-y-3">
              {data?.campaignROI.map((campaign, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{campaign.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Spent: ${campaign.spent.toLocaleString()} · Revenue: ${campaign.revenue.toLocaleString()}
                    </p>
                  </div>
                  <span className="text-sm font-bold text-success">{campaign.roi}%</span>
                </div>
              ))}
            </div>
          </MaterialCard>

          <MaterialCard>
            <h3 className="text-lg font-semibold text-foreground mb-4">Top Performers</h3>
            <div className="space-y-3">
              {data?.topPerformers.map((performer, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{performer.name}</p>
                    <p className="text-xs text-muted-foreground">{performer.deals} deals</p>
                  </div>
                  <span className="text-sm font-bold text-primary">${performer.revenue.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </MaterialCard>
        </div>
      </div>
    </AppLayout>
  )
}
