"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { Plus, Edit2, Trash2, TrendingUp, Users, DollarSign } from "lucide-react"
import { AppLayout } from "@/components/app-layout"
import { MaterialCard } from "@/components/material-card"
import { ModalDialog } from "@/components/modal-dialog"
import { AlertMessage } from "@/components/alert-message"
import { LoadingSpinner } from "@/components/loading-spinner"
import { apiGetCampaigns, apiCreateCampaign, apiUpdateCampaign, apiDeleteCampaign, type Campaign } from "@/lib/api"
import { cn } from "@/lib/cn"

type FilterStatus = "all" | Campaign["status"]

export default function CampaignsPage() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [filteredCampaigns, setFilteredCampaigns] = useState<Campaign[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<FilterStatus>("all")
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingCampaign, setEditingCampaign] = useState<Campaign | null>(null)
  const [alert, setAlert] = useState<{ type: "success" | "error"; message: string } | null>(null)

  useEffect(() => {
    loadCampaigns()
  }, [])

  useEffect(() => {
    if (filter === "all") {
      setFilteredCampaigns(campaigns)
    } else {
      setFilteredCampaigns(campaigns.filter((c) => c.status === filter))
    }
  }, [filter, campaigns])

  async function loadCampaigns() {
    try {
      setLoading(true)
      const data = await apiGetCampaigns()
      setCampaigns(data)
      setFilteredCampaigns(data)
    } catch (error) {
      console.error("Failed to load campaigns:", error)
      setAlert({ type: "error", message: "Failed to load campaigns" })
    } finally {
      setLoading(false)
    }
  }

  function openCreateModal() {
    setEditingCampaign(null)
    setIsModalOpen(true)
  }

  function openEditModal(campaign: Campaign) {
    setEditingCampaign(campaign)
    setIsModalOpen(true)
  }

  async function handleDelete(campaign: Campaign) {
    if (!confirm(`Are you sure you want to delete "${campaign.name}"?`)) return

    try {
      await apiDeleteCampaign(campaign.id)
      setCampaigns(campaigns.filter((c) => c.id !== campaign.id))
      setAlert({ type: "success", message: "Campaign deleted successfully" })
    } catch (error) {
      console.error("Failed to delete campaign:", error)
      setAlert({ type: "error", message: "Failed to delete campaign" })
    }
  }

  const statusColors: Record<Campaign["status"], string> = {
    active: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
    paused: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300",
    completed: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300",
  }

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <LoadingSpinner size="lg" />
        </div>
      </AppLayout>
    )
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Campaigns</h1>
            <p className="text-sm text-muted-foreground">{campaigns.length} total campaigns</p>
          </div>
          <button
            onClick={openCreateModal}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            <Plus className="h-4 w-4" />
            New Campaign
          </button>
        </div>

        {/* Alert */}
        {alert && <AlertMessage type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}

        {/* Filter Tabs */}
        <div className="flex gap-2">
          {(["all", "active", "paused", "completed"] as FilterStatus[]).map((status) => (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-colors capitalize",
                filter === status ? "bg-primary text-primary-foreground" : "bg-card text-foreground hover:bg-muted",
              )}
            >
              {status}
            </button>
          ))}
        </div>

        {/* Campaigns Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredCampaigns.map((campaign) => (
            <CampaignCard
              key={campaign.id}
              campaign={campaign}
              onEdit={() => openEditModal(campaign)}
              onDelete={() => handleDelete(campaign)}
              statusColors={statusColors}
            />
          ))}
        </div>

        {/* Campaign Form Modal */}
        <ModalDialog
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title={editingCampaign ? "Edit Campaign" : "Create New Campaign"}
          size="lg"
        >
          <CampaignForm
            campaign={editingCampaign}
            onSubmit={async (campaignData) => {
              try {
                if (editingCampaign) {
                  await apiUpdateCampaign(editingCampaign.id, campaignData)
                  setCampaigns(campaigns.map((c) => (c.id === editingCampaign.id ? { ...c, ...campaignData } : c)))
                  setAlert({ type: "success", message: "Campaign updated successfully" })
                } else {
                  const newCampaign = await apiCreateCampaign(campaignData)
                  setCampaigns([...campaigns, newCampaign])
                  setAlert({ type: "success", message: "Campaign created successfully" })
                }
                setIsModalOpen(false)
              } catch (error) {
                console.error("Failed to save campaign:", error)
                setAlert({ type: "error", message: "Failed to save campaign" })
              }
            }}
            onCancel={() => setIsModalOpen(false)}
          />
        </ModalDialog>
      </div>
    </AppLayout>
  )
}

function CampaignCard({
  campaign,
  onEdit,
  onDelete,
  statusColors,
}: {
  campaign: Campaign
  onEdit: () => void
  onDelete: () => void
  statusColors: Record<Campaign["status"], string>
}) {
  const budgetProgress = (campaign.spent / campaign.budget) * 100
  const conversionRate = campaign.leads > 0 ? ((campaign.conversions / campaign.leads) * 100).toFixed(1) : "0"
  const roi = campaign.spent > 0 ? (((campaign.revenue - campaign.spent) / campaign.spent) * 100).toFixed(0) : "0"

  return (
    <MaterialCard className="flex flex-col">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-foreground">{campaign.name}</h3>
          <span
            className={cn(
              "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mt-2",
              statusColors[campaign.status],
            )}
          >
            {campaign.status}
          </span>
        </div>
        <div className="flex gap-1">
          <button onClick={onEdit} className="p-2 rounded-lg hover:bg-muted transition-colors">
            <Edit2 className="h-4 w-4 text-primary" />
          </button>
          <button onClick={onDelete} className="p-2 rounded-lg hover:bg-muted transition-colors">
            <Trash2 className="h-4 w-4 text-destructive" />
          </button>
        </div>
      </div>

      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{campaign.description}</p>

      {/* Budget Progress */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-sm mb-1">
          <span className="text-muted-foreground">Budget</span>
          <span className="font-medium text-foreground">
            ${campaign.spent.toLocaleString()} / ${campaign.budget.toLocaleString()}
          </span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-secondary transition-all"
            style={{ width: `${Math.min(budgetProgress, 100)}%` }}
          />
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="text-center p-3 rounded-lg bg-muted/50">
          <Users className="h-4 w-4 text-primary mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Leads</p>
          <p className="text-sm font-bold text-foreground">{campaign.leads}</p>
        </div>
        <div className="text-center p-3 rounded-lg bg-muted/50">
          <TrendingUp className="h-4 w-4 text-secondary mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">Conv. Rate</p>
          <p className="text-sm font-bold text-foreground">{conversionRate}%</p>
        </div>
        <div className="text-center p-3 rounded-lg bg-muted/50">
          <DollarSign className="h-4 w-4 text-success mx-auto mb-1" />
          <p className="text-xs text-muted-foreground">ROI</p>
          <p className="text-sm font-bold text-foreground">{roi}%</p>
        </div>
      </div>

      {/* Channels */}
      <div className="flex flex-wrap gap-1 mt-auto">
        {campaign.channels.map((channel, index) => (
          <span key={index} className="px-2 py-1 rounded text-xs bg-primary/10 text-primary">
            {channel}
          </span>
        ))}
      </div>
    </MaterialCard>
  )
}

function CampaignForm({
  campaign,
  onSubmit,
  onCancel,
}: {
  campaign: Campaign | null
  onSubmit: (data: Partial<Campaign>) => void
  onCancel: () => void
}) {
  const [formData, setFormData] = useState<Partial<Campaign>>(
    campaign || {
      name: "",
      status: "active",
      budget: 0,
      startDate: "",
      endDate: "",
      channels: [],
      description: "",
    },
  )

  const [channelsInput, setChannelsInput] = useState(campaign?.channels.join(", ") || "")

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const channels = channelsInput
      .split(",")
      .map((c) => c.trim())
      .filter(Boolean)
    onSubmit({ ...formData, channels })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-foreground mb-1">Campaign Name *</label>
          <input
            type="text"
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Status *</label>
          <select
            required
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value as Campaign["status"] })}
            className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          >
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="completed">Completed</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Budget *</label>
          <input
            type="number"
            required
            min="0"
            value={formData.budget}
            onChange={(e) => setFormData({ ...formData, budget: Number(e.target.value) })}
            className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Start Date *</label>
          <input
            type="date"
            required
            value={formData.startDate}
            onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
            className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-1">End Date *</label>
          <input
            type="date"
            required
            value={formData.endDate}
            onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
            className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-foreground mb-1">Channels (comma separated)</label>
          <input
            type="text"
            placeholder="e.g. Social Media, Email, Website"
            value={channelsInput}
            onChange={(e) => setChannelsInput(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-foreground mb-1">Description</label>
          <textarea
            rows={3}
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
          />
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <button
          type="submit"
          className="flex-1 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors font-medium"
        >
          {campaign ? "Update Campaign" : "Create Campaign"}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 rounded-lg bg-muted text-foreground hover:bg-muted/80 transition-colors font-medium"
        >
          Cancel
        </button>
      </div>
    </form>
  )
}
