"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type User = {
  id: string
  email: string
  name: string
}

type AuthContextType = {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isAuthenticated: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function Providers({ children }: { children: ReactNode }) {
  return <AuthProvider>{children}</AuthProvider>
}

function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)

  useEffect(() => {
    // Check for existing session
    if (typeof window !== "undefined") {
      const token = localStorage.getItem("token")
      const userData = localStorage.getItem("user")
      if (token && userData) {
        setUser(JSON.parse(userData))
      }
    }
  }, [])

  const login = async (email: string, password: string) => {
    // Mock authentication
    const validUsers = [
      { id: "1", email: "admin@idss.ba", password: "password123", name: "Admin User" },
      { id: "2", email: "lamia@idss.ba", password: "lamia123", name: "Lamia" },
    ]

    const user = validUsers.find((u) => u.email === email && u.password === password)

    if (user) {
      const userData = { id: user.id, email: user.email, name: user.name }
      setUser(userData)
      if (typeof window !== "undefined") {
        localStorage.setItem("token", "mock-jwt-token")
        localStorage.setItem("user", JSON.stringify(userData))
      }
      return true
    }
    return false
  }

  const logout = () => {
    setUser(null)
    if (typeof window !== "undefined") {
      localStorage.removeItem("token")
      localStorage.removeItem("user")
    }
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>{children}</AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
