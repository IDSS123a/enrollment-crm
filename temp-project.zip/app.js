const ChartJS = window.Chart;

function App() {
  try {
    const [isAuthenticated, setIsAuthenticated] = React.useState(false);
    const [currentPage, setCurrentPage] = React.useState('dashboard');
    const [isLoading, setIsLoading] = React.useState(true);
    const [sheetsConnected, setSheetsConnected] = React.useState(false);
    const [language, setLanguage] = React.useState(localStorage.getItem('app_language') || 'EN');
    const [theme, setTheme] = React.useState(localStorage.getItem('app_theme') || 'light');

    React.useEffect(() => {
      const token = localStorage.getItem('idss_token');
      const sheetsAuth = localStorage.getItem('sheets_connected');
      const savedLang = localStorage.getItem('app_language');
      const savedTheme = localStorage.getItem('app_theme');
      
      if (token) {
        setIsAuthenticated(true);
      }
      if (sheetsAuth) {
        setSheetsConnected(true);
      }
      if (savedLang) {
        setLanguage(savedLang);
      }
      if (savedTheme) {
        setTheme(savedTheme);
        document.documentElement.setAttribute('data-theme', savedTheme);
      }
      setIsLoading(false);
    }, []);

    const handleLanguageChange = (newLang) => {
      setLanguage(newLang);
      localStorage.setItem('app_language', newLang);
    };

    const handleThemeChange = (newTheme) => {
      setTheme(newTheme);
      localStorage.setItem('app_theme', newTheme);
      document.documentElement.setAttribute('data-theme', newTheme);
    };

    const handleLogin = (token, user) => {
      localStorage.setItem('idss_token', token);
      localStorage.setItem('idss_user', JSON.stringify(user));
      setIsAuthenticated(true);
    };

    const handleLogout = () => {
      localStorage.removeItem('idss_token');
      localStorage.removeItem('idss_user');
      setIsAuthenticated(false);
      setCurrentPage('dashboard');
    };

    if (isLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-[var(--primary-color)] border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="mt-4 text-[var(--text-secondary)]">Loading...</p>
          </div>
        </div>
      );
    }

    if (!isAuthenticated) {
      return <LoginPage onLogin={handleLogin} />;
    }

    return (
      <div className="flex h-screen bg-[var(--bg-secondary)]" data-name="app" data-file="app.js">
        <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} onLogout={handleLogout} sheetsConnected={sheetsConnected} language={language} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header 
            sheetsConnected={sheetsConnected} 
            setSheetsConnected={setSheetsConnected}
            language={language}
            onLanguageChange={handleLanguageChange}
            theme={theme}
            onThemeChange={handleThemeChange}
          />
          <main className="flex-1 overflow-y-auto p-6">
            {currentPage === 'dashboard' && <DashboardPage sheetsConnected={sheetsConnected} language={language} />}
            {currentPage === 'leads' && <LeadsPage sheetsConnected={sheetsConnected} language={language} />}
            {currentPage === 'analytics' && <AnalyticsPage language={language} />}
            {currentPage === 'campaigns' && <CampaignsPage language={language} />}
            {currentPage === 'settings' && <SettingsPage setSheetsConnected={setSheetsConnected} language={language} />}
          </main>
        </div>
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

function LoginPage({ onLogin }) {
  try {
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');
    const [error, setError] = React.useState('');
    const [isLoading, setIsLoading] = React.useState(false);

    const handleSubmit = async (e) => {
      e.preventDefault();
      setError('');
      setIsLoading(true);

      try {
        const response = await apiLogin({ email, password });
        onLogin(response.token, response.user);
      } catch (err) {
        setError(err.message || 'Login failed. Please check your credentials.');
      } finally {
        setIsLoading(false);
      }
    };

    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-blue-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full">
          <div className="bg-white rounded-2xl shadow-2xl p-8">
            <div className="text-center mb-8">
              <div className="mx-auto w-20 h-20 mb-4">
                <img src="https://i.postimg.cc/zGfMdQfF/IDSS-Logo.png" alt="IDSS Logo" className="w-full h-full object-contain" />
              </div>
              <h1 className="text-3xl font-bold text-[var(--text-primary)]">IDSS Pro</h1>
              <p className="text-[var(--text-secondary)] mt-2">Advanced Enrollment CRM Platform</p>
            </div>

            {error && <Alert type="error" message={error} onClose={() => setError('')} />}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Email Address</label>
                <input
                  type="email"
                  className="input"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@idss.ba"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Password</label>
                <input
                  type="password"
                  className="input"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                />
              </div>
              <button type="submit" className="btn btn-primary w-full" disabled={isLoading}>
                {isLoading ? 'Signing in...' : 'Sign In'}
              </button>
            </form>

            <div className="mt-6 p-4 bg-indigo-50 rounded-lg border border-indigo-100">
              <p className="text-sm text-[var(--text-secondary)]">
                <strong className="text-[var(--text-primary)]">Demo Credentials:</strong><br />
                Admin: admin@idss.ba / password123<br />
                Lamia: lamia@idss.ba / lamia123
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('LoginPage error:', error);
    return null;
  }
}

function DashboardPage({ sheetsConnected, language }) {
  try {
    const [data, setData] = React.useState(null);
    const [isLoading, setIsLoading] = React.useState(true);
    const [activities, setActivities] = React.useState([]);

    React.useEffect(() => {
      fetchDashboardData();
      fetchRecentActivities();
    }, []);

    const fetchDashboardData = async () => {
      try {
        const dashboardData = await apiGetDashboard();
        setData(dashboardData);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    const fetchRecentActivities = async () => {
      try {
        const activityData = await apiGetActivities();
        setActivities(activityData);
      } catch (error) {
        console.error('Failed to fetch activities:', error);
      }
    };

    if (isLoading) {
      return <div className="text-center py-8">Loading dashboard...</div>;
    }

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-[var(--text-primary)]">{t('dashboard.title', language)}</h1>
          {sheetsConnected && (
            <div className="flex items-center gap-2 px-4 py-2 bg-green-50 border border-green-200 rounded-lg">
              <div className="icon-check-circle text-lg text-green-600"></div>
              <span className="text-sm font-medium text-green-700">Google Sheets Connected</span>
            </div>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title={t('dashboard.totalLeads', language)} value={data?.totalLeads || 0} icon="users" trend="+12.5%" />
          <StatCard title={t('dashboard.conversionRate', language)} value={`${data?.conversionRate || 0}%`} icon="trending-up" trend="+0.8%" />
          <StatCard title={t('dashboard.activeCampaigns', language)} value={data?.activeCampaigns || 0} icon="megaphone" trend="+2" />
          <StatCard title={t('dashboard.revenue', language)} value={`$${(data?.revenue || 0).toLocaleString()}`} icon="dollar-sign" trend="+18.2%" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 card">
            <h2 className="text-xl font-semibold mb-4">{t('dashboard.performanceTrends', language)}</h2>
            <LeadsChart data={data?.chartData || []} />
          </div>
          <div className="card">
            <h2 className="text-xl font-semibold mb-4">{t('dashboard.recentActivity', language)}</h2>
            <ActivityFeed activities={activities} />
          </div>
        </div>


      </div>
    );
  } catch (error) {
    console.error('DashboardPage error:', error);
    return null;
  }
}

function LeadsPage({ sheetsConnected }) {
  try {
    const [leads, setLeads] = React.useState([]);
    const [isLoading, setIsLoading] = React.useState(true);
    const [showModal, setShowModal] = React.useState(false);
    const [editingLead, setEditingLead] = React.useState(null);
    const [alert, setAlert] = React.useState(null);

    React.useEffect(() => {
      fetchLeads();
    }, []);

    const fetchLeads = async () => {
      setIsLoading(true);
      try {
        let data = await apiGetLeads();
        
        if (sheetsConnected) {
          try {
            console.log('Fetching leads from Google Sheets...');
            const sheetLeads = await loadFromGoogleSheets();
            if (sheetLeads && sheetLeads.length > 0) {
              console.log(`Found ${sheetLeads.length} leads from Google Sheets`);
              data = [...data, ...sheetLeads];
            } else {
              console.log('No leads found in Google Sheets');
            }
          } catch (error) {
            console.error('Failed to load from Google Sheets:', error);
            setAlert({ type: 'warning', message: 'Could not load data from Google Sheets. Showing local data only.' });
          }
        }
        
        setLeads(data);
      } catch (error) {
        console.error('Failed to fetch leads:', error);
        setAlert({ type: 'error', message: 'Failed to load leads data.' });
      } finally {
        setIsLoading(false);
      }
    };

    const handleAddLead = () => {
      setEditingLead(null);
      setShowModal(true);
    };

    const handleEditLead = (lead) => {
      setEditingLead(lead);
      setShowModal(true);
    };

    const handleSaveLead = async (leadData) => {
      try {
        if (editingLead) {
          await apiUpdateLead(editingLead.id, leadData);
        } else {
          await apiCreateLead(leadData);
        }
        
        if (sheetsConnected) {
          try {
            await syncToGoogleSheets(leadData);
            setAlert({ type: 'success', message: 'Lead saved and synced to Google Sheets!' });
          } catch (syncError) {
            console.error('Sync error:', syncError);
            setAlert({ type: 'warning', message: 'Lead saved locally but failed to sync to Google Sheets.' });
          }
        } else {
          setAlert({ type: 'success', message: editingLead ? 'Lead updated successfully!' : 'Lead created successfully!' });
        }
        
        setTimeout(() => fetchLeads(), 1000);
        setShowModal(false);
      } catch (error) {
        setAlert({ type: 'error', message: 'Failed to save lead. Please try again.' });
      }
    };

    const handleDeleteLead = async (leadId) => {
      if (confirm('Are you sure you want to delete this lead?')) {
        try {
          const lead = leads.find(l => l.id === leadId);
          await apiDeleteLead(leadId);
          
          if (sheetsConnected && lead && lead.email) {
            try {
              await deleteFromGoogleSheets(lead.email);
              setAlert({ type: 'success', message: 'Lead deleted from app and Google Sheets!' });
            } catch (syncError) {
              console.error('Failed to delete from Google Sheets:', syncError);
              setAlert({ type: 'warning', message: 'Lead deleted from app but could not be removed from Google Sheets.' });
            }
          } else {
            setAlert({ type: 'success', message: 'Lead deleted successfully!' });
          }
          
          fetchLeads();
        } catch (error) {
          setAlert({ type: 'error', message: 'Failed to delete lead.' });
        }
      }
    };

    return (
      <div className="space-y-6">
        {alert && <Alert type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}
        
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-[var(--text-primary)]">Leads Management</h1>
            <p className="text-[var(--text-secondary)] mt-1">Manage and track all your enrollment leads</p>
          </div>
          <div className="flex gap-3">
            {sheetsConnected && (
              <button className="btn btn-secondary" onClick={fetchLeads}>
                <div className="icon-refresh-cw text-lg"></div>
                Refresh from Sheets
              </button>
            )}
            <button className="btn btn-primary" onClick={handleAddLead}>
              <div className="icon-plus text-lg"></div>
              Add New Lead
            </button>
          </div>
        </div>

        <LeadsTable 
          leads={leads} 
          isLoading={isLoading} 
          onEdit={handleEditLead}
          onDelete={handleDeleteLead}
        />

        {showModal && (
          <Modal onClose={() => setShowModal(false)} title={editingLead ? 'Edit Lead' : 'Add New Lead'}>
            <LeadForm 
              lead={editingLead}
              onSave={handleSaveLead}
              onCancel={() => setShowModal(false)}
            />
          </Modal>
        )}
      </div>
    );
  } catch (error) {
    console.error('LeadsPage error:', error);
    return null;
  }
}

function AnalyticsPage() {
  try {
    const [analyticsData, setAnalyticsData] = React.useState(null);
    const [isLoading, setIsLoading] = React.useState(true);
    const [timeRange, setTimeRange] = React.useState('30d');

    React.useEffect(() => {
      fetchAnalytics();
    }, [timeRange]);

    const fetchAnalytics = async () => {
      setIsLoading(true);
      try {
        const data = await apiGetAnalytics(timeRange);
        setAnalyticsData(data);
      } catch (error) {
        console.error('Failed to fetch analytics:', error);
      } finally {
        setIsLoading(false);
      }
    };

    if (isLoading) {
      return <div className="text-center py-8">Loading analytics...</div>;
    }

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-[var(--text-primary)]">Analytics Dashboard</h1>
            <p className="text-[var(--text-secondary)] mt-1">Track performance and insights</p>
          </div>
          <select value={timeRange} onChange={(e) => setTimeRange(e.target.value)} className="input w-48">
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
            <option value="1y">Last Year</option>
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard title="Total Revenue" value={`$${analyticsData?.totalRevenue?.toLocaleString()}`} change="+24.5%" trend="up" icon="dollar-sign" />
          <MetricCard title="Avg Deal Size" value={`$${analyticsData?.avgDealSize?.toLocaleString()}`} change="+8.2%" trend="up" icon="trending-up" />
          <MetricCard title="Win Rate" value={`${analyticsData?.winRate}%`} change="+3.1%" trend="up" icon="target" />
          <MetricCard title="Sales Cycle" value={`${analyticsData?.salesCycle} days`} change="-2 days" trend="up" icon="clock" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card">
            <h2 className="text-xl font-semibold mb-4">Revenue Trends</h2>
            <PerformanceChart data={analyticsData?.revenueData} type="revenue" />
          </div>
          <div className="card">
            <h2 className="text-xl font-semibold mb-4">Conversion Funnel</h2>
            <PerformanceChart data={analyticsData?.funnelData} type="funnel" />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="card">
            <h2 className="text-xl font-semibold mb-4">Lead Sources Performance</h2>
            <div className="space-y-3">
              {analyticsData?.sourcePerformance?.map((source, idx) => (
                <div key={idx} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                      <div className={`icon-${source.icon} text-lg text-indigo-600`}></div>
                    </div>
                    <div>
                      <p className="font-medium text-[var(--text-primary)]">{source.name}</p>
                      <p className="text-xs text-[var(--text-secondary)]">{source.leads} leads</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-[var(--text-primary)]">${source.revenue?.toLocaleString()}</p>
                    <p className="text-xs text-green-600">{source.conversion}% conv.</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <h2 className="text-xl font-semibold mb-4">Campaign ROI</h2>
            <div className="space-y-3">
              {analyticsData?.campaignROI?.map((campaign, idx) => (
                <div key={idx} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <p className="font-medium text-[var(--text-primary)]">{campaign.name}</p>
                    <span className="text-sm font-bold text-green-600">{campaign.roi}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-gradient-to-r from-green-400 to-green-600 h-2 rounded-full" style={{width: `${Math.min(campaign.roi, 100)}%`}}></div>
                  </div>
                  <p className="text-xs text-[var(--text-secondary)] mt-1">Spent: ${campaign.spent?.toLocaleString()} | Revenue: ${campaign.revenue?.toLocaleString()}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <h2 className="text-xl font-semibold mb-4">Top Performers</h2>
            <div className="space-y-3">
              {analyticsData?.topPerformers?.map((performer, idx) => (
                <div key={idx} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center font-bold text-purple-600">
                    {idx + 1}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-[var(--text-primary)]">{performer.name}</p>
                    <p className="text-xs text-[var(--text-secondary)]">{performer.deals} deals closed</p>
                  </div>
                  <p className="font-bold text-[var(--text-primary)]">${performer.revenue?.toLocaleString()}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AnalyticsPage error:', error);
    return null;
  }
}

function CampaignsPage() {
  try {
    const [campaigns, setCampaigns] = React.useState([]);
    const [isLoading, setIsLoading] = React.useState(true);
    const [showModal, setShowModal] = React.useState(false);
    const [editingCampaign, setEditingCampaign] = React.useState(null);
    const [alert, setAlert] = React.useState(null);
    const [filterStatus, setFilterStatus] = React.useState('all');

    React.useEffect(() => {
      fetchCampaigns();
    }, []);

    const fetchCampaigns = async () => {
      setIsLoading(true);
      try {
        const data = await apiGetCampaigns();
        setCampaigns(data);
      } catch (error) {
        console.error('Failed to fetch campaigns:', error);
      } finally {
        setIsLoading(false);
      }
    };

    const handleAddCampaign = () => {
      setEditingCampaign(null);
      setShowModal(true);
    };

    const handleEditCampaign = (campaign) => {
      setEditingCampaign(campaign);
      setShowModal(true);
    };

    const handleSaveCampaign = async (campaignData) => {
      try {
        if (editingCampaign) {
          await apiUpdateCampaign(editingCampaign.id, campaignData);
          setAlert({ type: 'success', message: 'Campaign updated successfully!' });
        } else {
          await apiCreateCampaign(campaignData);
          setAlert({ type: 'success', message: 'Campaign created successfully!' });
        }
        fetchCampaigns();
        setShowModal(false);
      } catch (error) {
        setAlert({ type: 'error', message: 'Failed to save campaign.' });
      }
    };

    const handleDeleteCampaign = async (campaignId) => {
      if (confirm('Are you sure you want to delete this campaign?')) {
        try {
          await apiDeleteCampaign(campaignId);
          setAlert({ type: 'success', message: 'Campaign deleted successfully!' });
          fetchCampaigns();
        } catch (error) {
          setAlert({ type: 'error', message: 'Failed to delete campaign.' });
        }
      }
    };

    const filteredCampaigns = filterStatus === 'all' 
      ? campaigns 
      : campaigns.filter(c => c.status === filterStatus);

    return (
      <div className="space-y-6">
        {alert && <Alert type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}
        
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-[var(--text-primary)]">Campaigns Management</h1>
            <p className="text-[var(--text-secondary)] mt-1">Create and manage enrollment campaigns</p>
          </div>
          <button className="btn btn-primary" onClick={handleAddCampaign}>
            <div className="icon-plus text-lg"></div>
            Create Campaign
          </button>
        </div>

        <div className="flex gap-3">
          <button onClick={() => setFilterStatus('all')} className={`btn ${filterStatus === 'all' ? 'btn-primary' : 'btn-secondary'}`}>
            All Campaigns
          </button>
          <button onClick={() => setFilterStatus('active')} className={`btn ${filterStatus === 'active' ? 'btn-primary' : 'btn-secondary'}`}>
            Active
          </button>
          <button onClick={() => setFilterStatus('paused')} className={`btn ${filterStatus === 'paused' ? 'btn-primary' : 'btn-secondary'}`}>
            Paused
          </button>
          <button onClick={() => setFilterStatus('completed')} className={`btn ${filterStatus === 'completed' ? 'btn-primary' : 'btn-secondary'}`}>
            Completed
          </button>
        </div>

        {isLoading ? (
          <div className="text-center py-8">Loading campaigns...</div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredCampaigns.map(campaign => (
              <CampaignCard 
                key={campaign.id}
                campaign={campaign}
                onEdit={handleEditCampaign}
                onDelete={handleDeleteCampaign}
              />
            ))}
          </div>
        )}

        {showModal && (
          <Modal onClose={() => setShowModal(false)} title={editingCampaign ? 'Edit Campaign' : 'Create New Campaign'}>
            <CampaignForm 
              campaign={editingCampaign}
              onSave={handleSaveCampaign}
              onCancel={() => setShowModal(false)}
            />
          </Modal>
        )}
      </div>
    );
  } catch (error) {
    console.error('CampaignsPage error:', error);
    return null;
  }
}

function SettingsPage({ setSheetsConnected }) {
  try {
    const [alert, setAlert] = React.useState(null);
    const [isConnecting, setIsConnecting] = React.useState(false);
    const defaultUrl = 'https://script.google.com/macros/s/AKfycbxlnHBjYpHwedxru2BgbOmb8BtEqKtuv2ZOVl20UuWBLK5BI9enEjO9yxEXs_zLG7qH/exec';
    const [webAppUrl, setWebAppUrl] = React.useState(localStorage.getItem('sheets_web_app_url') || defaultUrl);
    const sheetsConnected = localStorage.getItem('sheets_connected') === 'true';

    React.useEffect(() => {
      const savedUrl = localStorage.getItem('sheets_web_app_url');
      if (!savedUrl || savedUrl !== defaultUrl) {
        localStorage.setItem('sheets_web_app_url', defaultUrl);
        setWebAppUrl(defaultUrl);
      }
    }, []);

    const handleConnectSheets = async () => {
      setIsConnecting(true);
      try {
        await initGoogleSheets();
        localStorage.setItem('sheets_connected', 'true');
        setSheetsConnected(true);
        setAlert({ type: 'success', message: 'Successfully connected to Google Sheets!' });
      } catch (error) {
        setAlert({ type: 'error', message: 'Failed to connect to Google Sheets.' });
      } finally {
        setIsConnecting(false);
      }
    };

    const handleDisconnect = () => {
      localStorage.removeItem('sheets_connected');
      localStorage.removeItem('sheets_web_app_url');
      setSheetsConnected(false);
      setWebAppUrl('');
      setAlert({ type: 'info', message: 'Disconnected from Google Sheets' });
    };

    const handleSaveWebAppUrl = () => {
      if (webAppUrl.trim()) {
        localStorage.setItem('sheets_web_app_url', webAppUrl.trim());
        setAlert({ type: 'success', message: 'Web App URL saved successfully!' });
      } else {
        setAlert({ type: 'error', message: 'Please enter a valid Web App URL' });
      }
    };

    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-[var(--text-primary)]">Settings</h1>
        
        {alert && <Alert type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}
        
        <div className="card">
          <h2 className="text-xl font-semibold mb-4">Google Sheets Integration</h2>
          <p className="text-[var(--text-secondary)] mb-4">Connect your Google Sheets to automatically sync lead data</p>
          
          {sheetsConnected ? (
            <div className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="icon-check-circle text-2xl text-green-600"></div>
                  <div>
                    <p className="font-semibold text-green-800">Connected to Google Sheets</p>
                    <p className="text-sm text-green-600">Spreadsheet ID: 1IMc5T_rB9w9j84P7kXS6bI_SHAFHQt5UF0M2wZz0C9o</p>
                  </div>
                </div>
              </div>
              <button className="btn btn-danger" onClick={handleDisconnect}>
                Disconnect
              </button>
            </div>
          ) : (
            <button className="btn btn-primary" onClick={handleConnectSheets} disabled={isConnecting}>
              {isConnecting ? 'Connecting...' : 'Connect Google Sheets'}
            </button>
          )}
        </div>

        <div className="card">
          <h2 className="text-xl font-semibold mb-4">Web App URL Configuration</h2>
          <p className="text-[var(--text-secondary)] mb-4">Enter your Google Apps Script Web App URL for automatic sync</p>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Web App URL</label>
              <input
                type="text"
                className="input"
                value={webAppUrl}
                onChange={(e) => setWebAppUrl(e.target.value)}
                placeholder="https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec"
              />
            </div>
            <div className="flex gap-3">
              <button className="btn btn-primary" onClick={handleSaveWebAppUrl}>
                Save Web App URL
              </button>
              <button className="btn btn-secondary" onClick={async () => {
                try {
                  setAlert({ type: 'info', message: 'Testing connection... Check console for details.' });
                  const result = await loadFromGoogleSheets();
                  if (result && result.length >= 0) {
                    setAlert({ type: 'success', message: `Connection successful! Found ${result.length} leads in Google Sheets.` });
                  } else {
                    setAlert({ type: 'warning', message: 'Connected but no leads found in sheet.' });
                  }
                } catch (error) {
                  setAlert({ type: 'error', message: 'Connection test failed. Check console for details.' });
                }
              }}>
                Test Connection
              </button>
            </div>
          </div>
        </div>
        
        <div className="card">
          <h2 className="text-xl font-semibold mb-4">Sheet Configuration</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Expected Columns</label>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-[var(--text-secondary)] font-mono">Date | Time | Name | Email | Phone | Status | Source</p>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Sheet Link</label>
              <a 
                href="https://docs.google.com/spreadsheets/d/1IMc5T_rB9w9j84P7kXS6bI_SHAFHQt5UF0M2wZz0C9o/edit" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[var(--primary-color)] hover:underline text-sm"
              >
                Open Google Sheet →
              </a>
            </div>
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800 font-medium mb-2">Setup Instructions:</p>
              <ol className="text-sm text-blue-700 space-y-1 list-decimal list-inside">
                <li>Ensure your Google Sheet has columns: Date, Time, Name, Email, Phone, Status, Source</li>
                <li>Lead data will be logged in the browser console when saved</li>
                <li>You can manually copy data from console to your sheet</li>
                <li>For automatic sync, Google Apps Script Web App deployment is required</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('SettingsPage error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
